﻿namespace RavaSync.API.Dto.CharaData;

public enum AccessTypeDto
{
    Individuals,
    ClosePairs,
    AllPairs,
    Public
}
