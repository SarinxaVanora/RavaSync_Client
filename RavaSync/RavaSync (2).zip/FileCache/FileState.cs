﻿namespace RavaSync.FileCache;

public enum FileState
{
    Valid,
    RequireUpdate,
    RequireDeletion,
}