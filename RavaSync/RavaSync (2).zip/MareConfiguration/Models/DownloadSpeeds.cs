﻿namespace RavaSync.MareConfiguration.Models;

public enum DownloadSpeeds
{
    Bps,
    KBps,
    MBps
}