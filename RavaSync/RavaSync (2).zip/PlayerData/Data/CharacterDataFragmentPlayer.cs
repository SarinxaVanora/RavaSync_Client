﻿namespace RavaSync.PlayerData.Data;

public class CharacterDataFragmentPlayer : CharacterDataFragment
{
    public string HeelsData { get; set; } = string.Empty;
    public string HonorificData { get; set; } = string.Empty;
    public string ManipulationString { get; set; } = string.Empty;
    public string MoodlesData { get; set; } = string.Empty;
    public string PetNamesData { get; set; } = string.Empty;
}
