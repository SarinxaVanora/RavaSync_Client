﻿namespace RavaSync.Services.Mediator;

public interface IMediatorSubscriber
{
    MareMediator Mediator { get; }
}