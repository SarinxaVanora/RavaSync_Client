﻿using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Colors;
using Dalamud.Interface.Textures.TextureWraps;
using Microsoft.Extensions.Logging;
using RavaSync.MareConfiguration;
using RavaSync.PlayerData.Handlers;
using RavaSync.PlayerData.Pairs;
using RavaSync.Services;
using RavaSync.Services.Mediator;
using RavaSync.WebAPI.Files;
using RavaSync.WebAPI.Files.Models;
using System.Collections.Concurrent;
using System.Numerics;
using RavaSync.PlayerData.Factories;
using ObjectKind = RavaSync.API.Data.Enum.ObjectKind;
using Dalamud.Plugin.Services;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Interface.Windowing;

namespace RavaSync.UI;

public class DownloadUi : WindowMediatorSubscriberBase
{
    
    
    
    private readonly MareConfigService _configService;
    private readonly ConcurrentDictionary<GameObjectHandler, DownloadAggregate> _currentDownloads = new();
    private static readonly TimeSpan DownloadUiHoldWindow = TimeSpan.FromSeconds(2);
    private readonly DalamudUtilService _dalamudUtilService;
    private readonly FileUploadManager _fileTransferManager;
    private readonly PairManager _pairManager;
    private readonly UiSharedService _uiShared;
    private readonly IObjectTable _objectTable;
    private IDalamudTextureWrap? _aetherFrame;
    private IDalamudTextureWrap? _aetherFill;
    private IDalamudTextureWrap? _aetherFillBlue;
    private readonly Dictionary<IntPtr, Vector2> _smoothedScreens = new();
    private const long MinVisibleDownloadBytes = 10L * 1024L * 1024L;

    private Vector2 _aetherFrameSize = Vector2.Zero;

    private const float FillUvX0 = 167f / 1462f;
    private const float FillUvX1 = 1299f / 1462f;
    private const float FillUvY0 = 65f / 238f;
    private const float FillUvY1 = 173f / 238f;

    private bool _globalTransfersExpanded = false;

    private sealed class DownloadAggregate
    {
        public Dictionary<string, FileDownloadStatus> Status = new();
        public long AccTotalBytes;
        public long AccTransferredBytes;
        public int AccTotalFiles;
        public int AccTransferredFiles;

        public DateTime LastUpdateUtc;
        public bool Finished;

        public float SmoothedPercent;
        public float AnimPhase;
    }



    public DownloadUi(ILogger<DownloadUi> logger, DalamudUtilService dalamudUtilService, MareConfigService configService, FileUploadManager fileTransferManager, PairManager pairManager, IObjectTable objectTable,
        MareMediator mediator, UiSharedService uiShared, PerformanceCollectorService performanceCollectorService)
        : base(logger, mediator, "RavaSync Downloads", performanceCollectorService)
    {
        _dalamudUtilService = dalamudUtilService;
        _configService = configService;
        _fileTransferManager = fileTransferManager;
        _uiShared = uiShared;
        _pairManager = pairManager;
        _objectTable = objectTable;

        SizeConstraints = new WindowSizeConstraints()
        {
            MaximumSize = new Vector2(500, 90),
            MinimumSize = new Vector2(500, 90),
        };

        Flags |= ImGuiWindowFlags.NoMove;
        Flags |= ImGuiWindowFlags.NoBackground;
        Flags |= ImGuiWindowFlags.NoInputs;
        Flags |= ImGuiWindowFlags.NoNavFocus;
        Flags |= ImGuiWindowFlags.NoResize;
        Flags |= ImGuiWindowFlags.NoScrollbar;
        Flags |= ImGuiWindowFlags.NoTitleBar;
        Flags |= ImGuiWindowFlags.NoDecoration;
        Flags |= ImGuiWindowFlags.NoFocusOnAppearing;

        DisableWindowSounds = true;

        ForceMainWindow = true;

        IsOpen = true;

        Mediator.Subscribe<DownloadStartedMessage>(this, (msg) =>
        {
            if (msg.DownloadId == null || !msg.CountsTowardGlobal) return;

            var now = DateTime.UtcNow;

            var snap = SnapshotStatus(msg.DownloadStatus);

            _currentDownloads.AddOrUpdate(msg.DownloadId,
                addValueFactory: _ =>
                {
                    return new DownloadAggregate
                    {
                        Status = snap,
                        LastUpdateUtc = now,
                        Finished = false
                    };
                },
                updateValueFactory: (_, existing) =>
                {
                    if (existing.Finished && (now - existing.LastUpdateUtc) <= DownloadUiHoldWindow)
                    {
                        var prevTotalBytes = existing.Status.Values.Sum(s => Math.Max(0, s.TotalBytes));
                        var prevTransferredBytes = existing.Status.Values.Sum(s => Math.Max(0, s.TransferredBytes));
                        var prevTotalFiles = existing.Status.Values.Sum(s => Math.Max(0, s.TotalFiles));
                        var prevTransferredFiles = existing.Status.Values.Sum(s => Math.Max(0, s.TransferredFiles));

                        var previousLooksComplete = prevTotalFiles > 0
                            ? prevTransferredFiles >= prevTotalFiles
                            : prevTotalBytes > 0 && prevTransferredBytes >= prevTotalBytes;

                        if (previousLooksComplete)
                        {
                            existing.AccTotalBytes += prevTotalBytes;
                            existing.AccTransferredBytes += prevTransferredBytes;
                            existing.AccTotalFiles += prevTotalFiles;
                            existing.AccTransferredFiles += prevTransferredFiles;
                        }
                        else
                        {
                            existing.AccTotalBytes = 0;
                            existing.AccTransferredBytes = 0;
                            existing.AccTotalFiles = 0;
                            existing.AccTransferredFiles = 0;
                        }
                    }

                    existing.Status = snap;
                    existing.LastUpdateUtc = now;
                    existing.Finished = false;
                    return existing;
                });
        });

        Mediator.Subscribe<DownloadFinishedMessage>(this, (msg) =>
        {
            if (msg.DownloadId == null) return;

            if (_currentDownloads.TryGetValue(msg.DownloadId, out var agg))
            {
                agg.Finished = true;
                agg.LastUpdateUtc = DateTime.UtcNow;
            }
        });

        Mediator.Subscribe<GposeStartMessage>(this, (_) => IsOpen = false);
        Mediator.Subscribe<GposeEndMessage>(this, (_) => IsOpen = true);
        EnsureAetherTextures();
    }

    protected override void DrawInternal()
    {
        var now = DateTime.UtcNow;
        var io = ImGui.GetIO();
        PruneExpiredDownloads(now);

        if (_configService.Current.ShowGlobalTransferBars || _configService.Current.ShowUploadProgress || _configService.Current.EditGlobalTransferOverlay)
        {
            DrawGlobalTransferOverlay(now);
        }


        if (_configService.Current.ShowTransferWindow)
        {
            try
            {
                var currentUploads = _fileTransferManager.GetCurrentUploadsSnapshot();
                if (currentUploads.Length > 0)
                {
                    var totalUploads = currentUploads.Length;

                    var doneUploads = 0;
                    long totalUploaded = 0;
                    long totalToUpload = 0;

                    foreach (var c in currentUploads)
                    {
                        if (c.IsTransferred) doneUploads++;
                        totalUploaded += c.Transferred;
                        totalToUpload += c.Total;
                    }

                    UiSharedService.DrawOutlinedFont($"▲", ImGuiColors.DalamudWhite, new Vector4(0, 0, 0, 255), 1);
                    ImGui.SameLine();
                    var xDistance = ImGui.GetCursorPosX();
                    UiSharedService.DrawOutlinedFont($"Compressing+Uploading {doneUploads}/{totalUploads}",
                        ImGuiColors.DalamudWhite, new Vector4(0, 0, 0, 255), 1);
                    ImGui.NewLine();
                    ImGui.SameLine(xDistance);
                    UiSharedService.DrawOutlinedFont(
                        $"{UiSharedService.ByteToString(totalUploaded, addSuffix: false)}/{UiSharedService.ByteToString(totalToUpload)}",
                        ImGuiColors.DalamudWhite, new Vector4(0, 0, 0, 255), 1);

                    if (_currentDownloads.Any()) ImGui.Separator();
                }
            }
            catch
            {
                // ignore errors thrown from UI
            }

            try
            {
                foreach (var item in _currentDownloads.ToArray())
                {
                    var statuses = item.Value.Status.Values;

                    var dlQueue = 0;
                    var dlProg = 0;
                    var dlDecomp = 0;

                    foreach (var s in statuses)
                    {
                        var remaining = Math.Max(0, s.TotalFiles - s.TransferredFiles);

                        switch (s.DownloadStatus)
                        {
                            case DownloadStatus.WaitingForSlot:
                                dlQueue += remaining;
                                break;

                            case DownloadStatus.WaitingForQueue:
                                dlQueue += remaining;
                                break;

                            case DownloadStatus.Downloading:
                                dlProg += remaining;
                                break;

                            case DownloadStatus.Decompressing:
                                dlDecomp += Math.Max(1, remaining);
                                break;
                        }
                    }


                    var totalFiles = item.Value.AccTotalFiles;
                    var transferredFiles = item.Value.AccTransferredFiles;
                    var totalBytes = item.Value.AccTotalBytes;
                    var transferredBytes = item.Value.AccTransferredBytes;

                    foreach (var s in statuses)
                    {
                        totalFiles += s.TotalFiles;
                        transferredFiles += s.TransferredFiles;
                        totalBytes += s.TotalBytes;
                        transferredBytes += s.TransferredBytes;
                    }

                    UiSharedService.DrawOutlinedFont($"▼", ImGuiColors.DalamudWhite, new Vector4(0, 0, 0, 255), 1);
                    ImGui.SameLine();
                    var xDistance = ImGui.GetCursorPosX();
                    var phase = DownloadProgressHints.GetPrimaryPhase(0, dlQueue, dlProg, dlDecomp);
                    var phaseLabel = DownloadProgressHints.GetPhaseLabel(phase);
                    var headerText = string.IsNullOrWhiteSpace(phaseLabel) ? item.Key.Name : $"{item.Key.Name} - {phaseLabel}";
                    UiSharedService.DrawOutlinedFont(headerText, ImGuiColors.DalamudWhite, new Vector4(0, 0, 0, 255), 1);
                    ImGui.NewLine();
                    ImGui.SameLine(xDistance);
                    UiSharedService.DrawOutlinedFont($"{transferredFiles}/{totalFiles} ({UiSharedService.ByteToString(transferredBytes, addSuffix: false)}/{UiSharedService.ByteToString(totalBytes)})", ImGuiColors.DalamudWhite, new Vector4(0, 0, 0, 255), 1);

                }
            }
            catch
            {
                // ignore errors thrown from UI
            }
        }

        if (_configService.Current.ShowTransferBars || _configService.Current.ShowUploading)
        {
            const byte transparency = 220;

            EnsureAetherTextures();
            var haveAether = _aetherFrame != null && _aetherFill != null && _aetherFrameSize.X > 1 && _aetherFrameSize.Y > 1;

            now = DateTime.UtcNow;
            var dtPos = io.DeltaTime;
            var keepKeys = new HashSet<IntPtr>();

            if (_configService.Current.ShowTransferBars)
            {
                foreach (var transfer in _currentDownloads.ToList())
                {
                    if (transfer.Value.Finished && (now - transfer.Value.LastUpdateUtc) > DownloadUiHoldWindow)
                    {
                        _currentDownloads.TryRemove(transfer.Key, out _);
                        continue;
                    }

                    var go = transfer.Key.GetGameObject();
                    var screenPos = _dalamudUtilService.WorldToScreen(go);
                    if (screenPos == Vector2.Zero) continue;

                    var statuses = transfer.Value.Status.Values;
                    if (statuses.Count == 0) continue;

                    var totalBytes = transfer.Value.AccTotalBytes;
                    var transferredBytes = transfer.Value.AccTransferredBytes;

                    foreach (var s in statuses)
                    {
                        totalBytes += s.TotalBytes;
                        transferredBytes += s.TransferredBytes;
                    }

                    if (totalBytes <= 0 || totalBytes < MinVisibleDownloadBytes)
                        continue;

                    keepKeys.Add(transfer.Key.Address);
                    screenPos = SmoothAndSnapScreen(transfer.Key.Address, screenPos, dtPos);

                    var allPreparing = statuses.All(s =>
                        (s.DownloadStatus == DownloadStatus.Initializing
                         || s.DownloadStatus == DownloadStatus.WaitingForSlot
                         || s.DownloadStatus == DownloadStatus.WaitingForQueue)
                        && s.TransferredBytes == 0);

                    var hasInit = statuses.Any(s => s.DownloadStatus == DownloadStatus.Initializing);
                    var hasQueue = statuses.Any(s => s.DownloadStatus == DownloadStatus.WaitingForQueue
                                                     || s.DownloadStatus == DownloadStatus.WaitingForSlot);
                    var hasProg = statuses.Any(s => s.DownloadStatus == DownloadStatus.Downloading);
                    var hasDecomp = statuses.Any(s => s.DownloadStatus == DownloadStatus.Decompressing);

                    var sInit = 0;
                    var sQueue = 0;
                    var sProg = 0;
                    var sDecomp = 0;

                    foreach (var s in statuses)
                    {
                        var remaining = Math.Max(0, s.TotalFiles - s.TransferredFiles);

                        switch (s.DownloadStatus)
                        {
                            case DownloadStatus.Initializing:
                                sInit += remaining > 0 ? remaining : 1;
                                break;

                            case DownloadStatus.WaitingForSlot:
                                sQueue += remaining;
                                break;

                            case DownloadStatus.WaitingForQueue:
                                sQueue += remaining;
                                break;

                            case DownloadStatus.Downloading:
                                sProg += remaining;
                                break;

                            case DownloadStatus.Decompressing:
                                sDecomp += Math.Max(1, remaining);
                                break;
                        }
                    }

                    var isWaiting = hasQueue && !hasProg && !hasDecomp;
                    var isInitializing = hasInit && !hasProg && !hasDecomp;
                    var shouldPulse = isWaiting || isInitializing;

                    double dlProgressPercent;
                    string downloadText;

                    var downloadPhase = DownloadProgressHints.GetPrimaryPhase(sInit, sQueue, sProg, sDecomp);

                    if (isWaiting || isInitializing)
                    {
                        dlProgressPercent = 0.0;
                        downloadText = DownloadProgressHints.GetPhaseLabel(downloadPhase);
                    }
                    else
                    {
                        dlProgressPercent = totalBytes <= 0 ? 0.0 : transferredBytes / (double)totalBytes;
                        dlProgressPercent = Math.Clamp(dlProgressPercent, 0.0, 1.0);
                        downloadText = DownloadProgressHints.FormatProgressText(downloadPhase, transferredBytes, totalBytes);
                    }

                    var dt = io.DeltaTime;
                    var target = (isWaiting || isInitializing) ? 0f : (float)dlProgressPercent;

                    transfer.Value.SmoothedPercent = LerpExp(transfer.Value.SmoothedPercent, target, lambda: 12f, dt);
                    transfer.Value.AnimPhase += dt;

                    int dlBarWidth;
                    int dlBarHeight;

                    if (haveAether)
                    {
                        dlBarWidth = Math.Max(_configService.Current.TransferBarsWidth, 320);

                        var aspect = _aetherFrameSize.Y / _aetherFrameSize.X;
                        dlBarHeight = Math.Max(_configService.Current.TransferBarsHeight, (int)MathF.Round(dlBarWidth * aspect));

                        var minH = Math.Max(_configService.Current.TransferBarsHeight, 34);
                        if (dlBarHeight < minH) { dlBarHeight = minH; dlBarWidth = (int)MathF.Round(dlBarHeight / aspect); }

                        dlBarWidth = (int)MathF.Round(dlBarWidth * 1.10f);
                        dlBarHeight = (int)MathF.Round(dlBarHeight * 1.10f);
                    }
                    else
                    {
                        dlBarWidth = Math.Max(_configService.Current.TransferBarsWidth, 320);
                        dlBarHeight = Math.Max(_configService.Current.TransferBarsHeight, 28);
                    }

                    const float barYOffsetPx = 0f;

                    var barCenter = screenPos + new Vector2(0f, barYOffsetPx);

                    var dlBarStart = new Vector2(barCenter.X - dlBarWidth / 2f, barCenter.Y - dlBarHeight / 2f);
                    var dlBarEnd = new Vector2(barCenter.X + dlBarWidth / 2f, barCenter.Y + dlBarHeight / 2f);
                    dlBarStart = new Vector2(MathF.Round(dlBarStart.X), MathF.Round(dlBarStart.Y));
                    dlBarEnd = new Vector2(MathF.Round(dlBarEnd.X), MathF.Round(dlBarEnd.Y));

                    var drawList = ImGui.GetBackgroundDrawList();

                    DrawAetherBarComposite(drawList, dlBarStart, dlBarEnd, transfer.Value.SmoothedPercent, transparency, allPreparing, transfer.Value.AnimPhase);

                    if (_configService.Current.TransferBarsShowText)
                    {
                        GetFillRect(dlBarStart, dlBarEnd, out var fillStart, out var fillEnd);
                        var mid = (fillStart + fillEnd) * 0.5f;

                        var textSizeCurrent = ImGui.CalcTextSize(downloadText);

                        UiSharedService.DrawOutlinedFont(
                            drawList,
                            downloadText,
                            new Vector2(mid.X - textSizeCurrent.X / 2f, mid.Y - textSizeCurrent.Y / 2f),
                            UiSharedService.Color(255, 255, 255, 255),
                            UiSharedService.Color(0, 0, 0, 220),
                            2);
                    }
                }
            }

            if (_configService.Current.ShowUploading)
            {
                foreach (var pair in _pairManager.PairsWithGroups.Keys)
                {
                    if (!pair.IsUploading)
                        continue;

                    if (!TryResolveUploadingPlayerObject(pair, out var go, out var addr))
                        continue;

                    var screenPos2 = _dalamudUtilService.WorldToScreen(go);
                    if (screenPos2 == Vector2.Zero)
                        continue;

                    keepKeys.Add(addr);
                    screenPos2 = SmoothAndSnapScreen(addr, screenPos2, dtPos);

                    try
                    {
                        using var _ = _uiShared.UidFont.Push();
                        var uploadText = "Uploading";
                        var textSize = ImGui.CalcTextSize(uploadText);

                        var drawList = ImGui.GetBackgroundDrawList();
                        var tp = new Vector2(
                            MathF.Round(screenPos2.X - textSize.X / 2f - 1f),
                            MathF.Round(screenPos2.Y - textSize.Y / 2f - 1f)
                        );

                        UiSharedService.DrawOutlinedFont(
                            drawList,
                            uploadText,
                            tp,
                            UiSharedService.Color(112, 28, 180, 255),
                            UiSharedService.Color(0, 0, 0, 200),
                            2
                        );
                    }
                    catch
                    {
                        // ignore UI errors
                    }
                }
            }

            PruneSmoothedScreens(keepKeys);
        }

    }

    private static float LerpExp(float current, float target, float lambda, float dt)
    {
        var t = 1f - MathF.Exp(-lambda * dt);
        return current + (target - current) * t;
    }

    private static void DrawFillEdgeGlow(ImDrawListPtr dl, Vector2 fillStart, Vector2 fillEnd, float fillEndX, float phase, byte alpha)
    {
        var h = fillEnd.Y - fillStart.Y;
        if (h <= 2f) return;

        var insetY = MathF.Max(2f, h * 0.12f);
        var y0 = fillStart.Y + insetY;
        var y1 = fillEnd.Y - insetY;

        var coreW = MathF.Max(2f, h * 0.10f);
        var glowW = MathF.Max(10f, h * 0.55f);

        var t = (float)ImGui.GetTime();
        var pulse = 0.72f + 0.28f * (0.5f + 0.5f * MathF.Sin(t * 3.2f + phase * 0.9f));
        var wobble = MathF.Sin(t * 1.6f + phase * 1.1f) * (h * 0.04f);

        var aCore = (byte)Math.Clamp((int)(alpha * (0.65f + 0.25f * pulse)), 0, 255);
        var aGlow = (byte)Math.Clamp((int)(alpha * (0.28f + 0.22f * pulse)), 0, 255);
        var aSoft = (byte)Math.Clamp((int)(alpha * (0.12f + 0.10f * pulse)), 0, 255);

        var x = fillEndX;
        var centerY = (y0 + y1) * 0.5f + wobble;

        dl.AddRectFilled(
            new Vector2(x - glowW, y0),
            new Vector2(x + glowW, y1),
            UiSharedService.Color(210, 185, 255, aSoft),
            h * 0.35f);

        dl.AddRectFilled(
            new Vector2(x - glowW * 0.45f, y0),
            new Vector2(x + glowW * 0.45f, y1),
            UiSharedService.Color(170, 90, 255, aGlow),
            h * 0.35f);

        dl.AddRectFilled(
            new Vector2(x - coreW, y0),
            new Vector2(x + coreW, y1),
            UiSharedService.Color(255, 255, 255, aCore),
            h * 0.35f);

        var dotR = MathF.Max(1.5f, h * 0.10f);
        dl.AddCircleFilled(new Vector2(x, centerY), dotR, UiSharedService.Color(255, 255, 255, (byte)Math.Clamp(aCore + 30, 0, 255)), 12);
    }


    private static float PingPong(float t)
    {
        t %= 2f;
        return t < 1f ? t : 2f - t;
    }

    private static float Hash01(uint x)
    {
        x ^= x >> 16;
        x *= 0x7feb352d;
        x ^= x >> 15;
        x *= 0x846ca68b;
        x ^= x >> 16;
        return (x & 0x00FFFFFF) / 16777216f;
    }

    private static void DrawEnergyVialFill(ImDrawListPtr dl, Vector2 start, Vector2 end, float progress, float phase, byte alpha)
    {
        var w = end.X - start.X;
        var h = end.Y - start.Y;
        if (w <= 1 || h <= 1) return;

        progress = Math.Clamp(progress, 0f, 1f);
        var fillEndX = start.X + w * progress;
        if (fillEndX <= start.X + 1) return;

        dl.PushClipRect(start, new Vector2(fillEndX, end.Y), true);

        var top = UiSharedService.Color(165, 90, 255, alpha);
        var bot = UiSharedService.Color(70, 10, 120, alpha);
        dl.AddRectFilledMultiColor(start, end, top, top, bot, bot);

        var bandW = MathF.Max(18f, w * 0.12f);
        var speed = 80f;
        var offset = (phase * speed) % (bandW * 2f);

        byte shimmerA = (byte)(alpha * 0.22f);
        var shimmerCol = UiSharedService.Color(255, 255, 255, shimmerA);

        for (var x = start.X - bandW * 2f; x < fillEndX + bandW; x += bandW * 2f)
        {
            var x0 = x + offset;
            var x1 = x0 + bandW;

            if (x1 <= start.X || x0 >= fillEndX) continue;

            var ySkew = MathF.Sin(phase * 1.7f + x0 * 0.01f) * (h * 0.08f);

            var p0 = new Vector2(MathF.Max(x0, start.X), start.Y + ySkew);
            var p1 = new Vector2(MathF.Min(x1, fillEndX), end.Y + ySkew);

            dl.AddRectFilled(p0, p1, shimmerCol, 1f);
        }

        uint seed = (uint)start.GetHashCode() ^ (uint)end.GetHashCode();
        int bubbleCount = (int)Math.Clamp(w / 60f, 3f, 7f);

        byte bubbleA = (byte)(alpha * 0.35f);
        var bubbleCol = UiSharedService.Color(230, 210, 255, bubbleA);

        for (int i = 0; i < bubbleCount; i++)
        {
            var r01 = Hash01(seed + (uint)(i * 1013));
            var r02 = Hash01(seed + (uint)(i * 2027));

            var bx = start.X + r01 * (fillEndX - start.X);
            var rise = (phase * (0.45f + r02 * 0.8f) + i * 0.7f) % 1f;
            var by = end.Y - rise * h;

            var rad = 1.2f + r02 * 1.8f;
            dl.AddCircleFilled(new Vector2(bx, by), rad, bubbleCol, 10);
        }

        dl.PopClipRect();

        byte surfaceA = (byte)(alpha * 0.55f);
        var surfaceCol = UiSharedService.Color(220, 200, 255, surfaceA);
        dl.AddLine(new Vector2(start.X, start.Y), new Vector2(fillEndX, start.Y), surfaceCol, 1.0f);
    }


    private void DrawAetherBarComposite(ImDrawListPtr dl, Vector2 start, Vector2 end, float progress, byte alpha, bool isPreparing, float phase)
    {
        EnsureAetherTextures();

        if (_aetherFrame == null || _aetherFill == null || _aetherFrameSize.X <= 1 || _aetherFrameSize.Y <= 1)
        {
            DrawEnergyVialFill(dl, start, end, progress, phase: 0f, alpha);
            return;
        }

        var w = end.X - start.X;
        var h = end.Y - start.Y;
        if (w <= 1 || h <= 1) return;

        progress = Math.Clamp(progress, 0f, 1f);

        GetFillRect(start, end, out var fillStart, out var fillEnd);
        if (fillEnd.X <= fillStart.X || fillEnd.Y <= fillStart.Y) return;

        var rounding = MathF.Max(2f, h * 0.18f);

        dl.AddImage(_aetherFrame.Handle, start, end, Vector2.Zero, Vector2.One, UiSharedService.Color(255, 255, 255, alpha));

        var backA = (byte)Math.Clamp((int)(alpha * 0.10f), 0, 255);
        dl.AddRectFilled(fillStart, fillEnd, UiSharedService.Color(0, 0, 0, backA), rounding);

        var effectiveProgress = isPreparing ? 1f : progress;
        var fillEndX = fillStart.X + (fillEnd.X - fillStart.X) * effectiveProgress;

        var pulseMul = isPreparing ? (0.80f + 0.20f * PingPong((float)ImGui.GetTime() * 0.85f)) : 1f;
        var fillAInt = (int)((Math.Min(255, alpha + 55)) * pulseMul);
        fillAInt = Math.Clamp(fillAInt, 0, 255);

        var fillA = (byte)fillAInt;
        var glowA = (byte)Math.Clamp((int)(fillAInt * 0.70f), 0, 255);
        var highlightA = (byte)Math.Clamp((int)(fillAInt * 0.22f), 0, 255);

        if (fillEndX > fillStart.X + 0.5f)
        {
            dl.PushClipRect(fillStart, new Vector2(fillEndX, fillEnd.Y), true);

            
            dl.AddImage(_aetherFill.Handle, start, end, Vector2.Zero, Vector2.One, UiSharedService.Color(255, 255, 255, fillA));
            
            dl.AddImage(_aetherFill.Handle, start + new Vector2(0f, -1f), end + new Vector2(0f, -1f), Vector2.Zero, Vector2.One, UiSharedService.Color(255, 255, 255, glowA));
            
            dl.AddRectFilledMultiColor(
                fillStart, fillEnd,
                UiSharedService.Color(255, 255, 255, highlightA),
                UiSharedService.Color(255, 255, 255, highlightA),
                UiSharedService.Color(140, 60, 230, 0),
                UiSharedService.Color(140, 60, 230, 0));

            dl.PopClipRect();

            if (!isPreparing && progress > 0f && progress < 1f)
            {
                var edgeA = (byte)Math.Min((int)alpha, 230);
                dl.AddLine(new Vector2(fillEndX, fillStart.Y + 1f), new Vector2(fillEndX, fillEnd.Y - 1f), UiSharedService.Color(255, 255, 255, edgeA), 2.0f);
                dl.AddLine(new Vector2(fillEndX - 1f, fillStart.Y + 1f), new Vector2(fillEndX - 1f, fillEnd.Y - 1f), UiSharedService.Color(235, 200, 255, (byte)Math.Clamp((int)(edgeA * 0.55f), 0, 255)), 3.0f);

                DrawFillEdgeGlow(dl, fillStart, fillEnd, fillEndX, phase, edgeA);
            }

        }

        DrawFrameBorderOnly(dl, start, end, fillStart, fillEnd, alpha);
    }
    private void DrawFrameBorderOnly(ImDrawListPtr dl, Vector2 start, Vector2 end, Vector2 holeStart, Vector2 holeEnd, byte alpha)
    {
        if (_aetherFrame == null) return;

        var col = UiSharedService.Color(255, 255, 255, alpha);

        // Top strip
        dl.PushClipRect(start, new Vector2(end.X, holeStart.Y), true);
        dl.AddImage(_aetherFrame.Handle, start, end, Vector2.Zero, Vector2.One, col);
        dl.PopClipRect();

        // Bottom strip
        dl.PushClipRect(new Vector2(start.X, holeEnd.Y), end, true);
        dl.AddImage(_aetherFrame.Handle, start, end, Vector2.Zero, Vector2.One, col);
        dl.PopClipRect();

        // Left strip
        dl.PushClipRect(new Vector2(start.X, holeStart.Y), new Vector2(holeStart.X, holeEnd.Y), true);
        dl.AddImage(_aetherFrame.Handle, start, end, Vector2.Zero, Vector2.One, col);
        dl.PopClipRect();

        // Right strip
        dl.PushClipRect(new Vector2(holeEnd.X, holeStart.Y), new Vector2(end.X, holeEnd.Y), true);
        dl.AddImage(_aetherFrame.Handle, start, end, Vector2.Zero, Vector2.One, col);
        dl.PopClipRect();
    }


    private static void GetFillRect(Vector2 start, Vector2 end, out Vector2 fillStart, out Vector2 fillEnd)
    {
        var w = end.X - start.X;
        var h = end.Y - start.Y;
        fillStart = new Vector2(start.X + w * FillUvX0, start.Y + h * FillUvY0);
        fillEnd = new Vector2(start.X + w * FillUvX1, start.Y + h * FillUvY1);
    }


    private void EnsureAetherTextures()
    {
        if (_aetherFrame != null && _aetherFill != null && _aetherFillBlue != null) return;

        try
        {
            _aetherFrame = _uiShared.LoadImage(ReadEmbedded("RavaSync.Resources.aether_frame_bar.png"));
            _aetherFill = _uiShared.LoadImage(ReadEmbedded("RavaSync.Resources.aether_fill_strip.png"));
            _aetherFillBlue = _uiShared.LoadImage(ReadEmbedded("RavaSync.Resources.aether_fill_blue.png"));

            if (_aetherFrame != null) _aetherFrameSize = new Vector2(_aetherFrame.Width, _aetherFrame.Height);
        }
        catch
        {
            _aetherFrame = null;
            _aetherFill = null;
            _aetherFillBlue = null;
            _aetherFrameSize = Vector2.Zero;
        }
    }

    private static byte[] ReadEmbedded(string resourceName)
    {
        using var s = typeof(DownloadUi).Assembly.GetManifestResourceStream(resourceName);
        if (s == null) throw new FileNotFoundException("Missing embedded resource: " + resourceName);

        using var ms = new MemoryStream();
        s.CopyTo(ms);
        return ms.ToArray();
    }


    private void PruneExpiredDownloads(DateTime nowUtc)
    {
        foreach (var kv in _currentDownloads.ToList())
        {
            if (kv.Value.Finished && (nowUtc - kv.Value.LastUpdateUtc) > DownloadUiHoldWindow)
                _currentDownloads.TryRemove(kv.Key, out _);
        }
    }

    private static bool AnyUploadsActive(FileUploadManager mgr)
        => mgr.GetCurrentUploadsSnapshot().Length > 0;

    private (int W, int H) GetGlobalBarSize(bool haveAether)
    {
        var baseW = Math.Max(_configService.Current.TransferBarsWidth, 520);
        var baseH = Math.Max(_configService.Current.TransferBarsHeight, 40);

        var w = (int)MathF.Round(baseW * 1.15f);

        if (!haveAether || _aetherFrameSize.X <= 1 || _aetherFrameSize.Y <= 1)
        {
            var h2 = (int)MathF.Round(baseH * 1.15f);
            h2 = Math.Clamp(h2, 34, 90);
            return (w, h2);
        }

        var aspect = _aetherFrameSize.Y / _aetherFrameSize.X;
        var hCalc = (int)MathF.Round(w * aspect);

        var h = Math.Max((int)MathF.Round(baseH * 1.15f), hCalc);
        h = Math.Clamp(h, 34, 90);

        if (h != hCalc)
            w = (int)MathF.Round(h / aspect);

        return (w, h);
    }


    private void DrawUploadBarCompositeBlue(ImDrawListPtr dl, Vector2 start, Vector2 end, float progress, byte alpha, float phase)
    {
        EnsureAetherTextures();

        var fillTex = _aetherFillBlue ?? _aetherFill;

        if (_aetherFrame == null || fillTex == null || _aetherFrameSize.X <= 1 || _aetherFrameSize.Y <= 1)
        {
            DrawEnergyVialFill(dl, start, end, progress, phase, alpha);
            return;
        }

        var w = end.X - start.X;
        var h = end.Y - start.Y;
        if (w <= 1 || h <= 1) return;

        progress = Math.Clamp(progress, 0f, 1f);

        GetFillRect(start, end, out var fillStart, out var fillEnd);
        if (fillEnd.X <= fillStart.X || fillEnd.Y <= fillStart.Y) return;

        var rounding = MathF.Max(2f, h * 0.18f);

        dl.AddImage(_aetherFrame.Handle, start, end, Vector2.Zero, Vector2.One, UiSharedService.Color(255, 255, 255, alpha));

        var backA = (byte)Math.Clamp((int)(alpha * 0.10f), 0, 255);
        dl.AddRectFilled(fillStart, fillEnd, UiSharedService.Color(0, 0, 0, backA), rounding);

        var fillEndX = fillStart.X + (fillEnd.X - fillStart.X) * progress;
        if (fillEndX <= fillStart.X + 0.5f)
        {
            DrawFrameBorderOnly(dl, start, end, fillStart, fillEnd, alpha);
            return;
        }

        dl.PushClipRect(fillStart, new Vector2(fillEndX, fillEnd.Y), true);


        var baseTint = UiSharedService.Color(170, 220, 255, alpha);
        var glowTint = UiSharedService.Color(120, 190, 255, (byte)(alpha * 0.70f));

        dl.AddImage(fillTex.Handle, start, end, Vector2.Zero, Vector2.One, UiSharedService.Color(255, 255, 255, alpha));
        dl.AddImage(fillTex.Handle, start + new Vector2(0f, -1f), end + new Vector2(0f, -1f), Vector2.Zero, Vector2.One, UiSharedService.Color(255, 255, 255, (byte)(alpha * 0.70f)));

        var highlightA = (byte)Math.Clamp((int)(alpha * 0.18f), 0, 255);
        dl.AddRectFilledMultiColor(
            fillStart, fillEnd,
            UiSharedService.Color(255, 255, 255, highlightA),
            UiSharedService.Color(255, 255, 255, highlightA),
            UiSharedService.Color(80, 140, 220, 0),
            UiSharedService.Color(80, 140, 220, 0));

        dl.PopClipRect();

        DrawFrameBorderOnly(dl, start, end, fillStart, fillEnd, alpha);
    }


    private void DrawGlobalTransferOverlay(DateTime nowUtc)
    {
        var editing = _configService.Current.EditGlobalTransferOverlay;

        var haveDownloads = _currentDownloads.Any() || editing;
        var haveUploads = (_configService.Current.ShowUploadProgress && AnyUploadsActive(_fileTransferManager)) || editing;

        var anyVisibleDl = false;
        var currentDownloadsSnapshot = _currentDownloads.ToArray();

        if (!editing)
        {
            if (!_configService.Current.ShowGlobalTransferBars && !haveUploads) return;
            if (!_configService.Current.ShowGlobalTransferBars && !haveDownloads && !haveUploads) return;
        }

        EnsureAetherTextures();
        var haveAether = _aetherFrame != null && _aetherFill != null && _aetherFrameSize.X > 1 && _aetherFrameSize.Y > 1;

        var (barWBase, barHBase) = GetGlobalBarSize(haveAether);

        var scale = Math.Clamp(_configService.Current.GlobalTransferOverlayScale, 0.70f, 1.60f);
        var barW = (int)MathF.Round(barWBase * scale);
        var barH = (int)MathF.Round(barHBase * scale);

        const byte alpha = 235;
        var gapX = 10f;
        var gapY = 8f;


        var flags = ImGuiWindowFlags.AlwaysAutoResize
            | ImGuiWindowFlags.NoFocusOnAppearing
            | ImGuiWindowFlags.NoNav;

        if (!editing)
        {
            flags |= ImGuiWindowFlags.NoDecoration;
            flags |= ImGuiWindowFlags.NoMove;
            //flags |= ImGuiWindowFlags.NoInputs;
        }

        ImGui.SetNextWindowBgAlpha(editing ? 0.35f : 0f);

        var vp = ImGui.GetMainViewport();
        var px = _configService.Current.GlobalTransferOverlayX;
        var py = _configService.Current.GlobalTransferOverlayY;

        if (px < 0f || py < 0f)
        {
            var defaultPos = vp.WorkPos + new Vector2(vp.WorkSize.X * 0.5f, 90f);
            ImGui.SetNextWindowPos(defaultPos, ImGuiCond.FirstUseEver, new Vector2(0.5f, 0f));
        }
        else
        {
            ImGui.SetNextWindowPos(new Vector2(px, py), editing ? ImGuiCond.FirstUseEver : ImGuiCond.Always);
        }

        var windowName = editing ? "RavaSync Transfers###RavaSyncGlobalTransfers" : "###RavaSyncGlobalTransfers";
        if (!ImGui.Begin(windowName, flags))
        {
            ImGui.End();
            return;
        }

        // Persist window position when editing
        if (editing && ImGui.IsMouseReleased(ImGuiMouseButton.Left))
        {
            var pos = ImGui.GetWindowPos();
            var changed =
                _configService.Current.GlobalTransferOverlayX < 0f ||
                _configService.Current.GlobalTransferOverlayY < 0f ||
                MathF.Abs(_configService.Current.GlobalTransferOverlayX - pos.X) > 0.5f ||
                MathF.Abs(_configService.Current.GlobalTransferOverlayY - pos.Y) > 0.5f;

            if (changed)
            {
                _configService.Current.GlobalTransferOverlayX = pos.X;
                _configService.Current.GlobalTransferOverlayY = pos.Y;
                _configService.Save();
            }
        }

        var dl = ImGui.GetWindowDrawList();
        var phase = (float)ImGui.GetTime();

        // ===== Editing controls =====
        if (editing)
        {
            ImGui.AlignTextToFramePadding();
            ImGui.TextUnformatted(_uiShared.L("UI.DownloadUi.011b8d1d", "Layout:"));
            ImGui.SameLine();

            var row = _configService.Current.GlobalTransferOverlayRowLayout;

            if (ImGui.RadioButton($"{_uiShared.L("UI.DownloadUi.29B733FD", "Stacked")}##globalLayout", !row))
            {
                _configService.Current.GlobalTransferOverlayRowLayout = false;
                _configService.Save();
                row = false;
            }

            ImGui.SameLine();
            if (ImGui.RadioButton($"{_uiShared.L("UI.DownloadUi.A70367AA", "Row")}##globalLayout", row))
            {
                _configService.Current.GlobalTransferOverlayRowLayout = true;
                _configService.Save();
                row = true;
            }

            ImGui.SameLine(0, 14f);
            ImGui.AlignTextToFramePadding();

            ImGui.SameLine(0, 14f);
            float s = _configService.Current.GlobalTransferOverlayScale;
            ImGui.SetNextItemWidth(160f);
            if (ImGui.SliderFloat($"{_uiShared.L("UI.DownloadUi.85A7CD58", "Scale")}##globalTransfers", ref s, 0.70f, 1.60f, "%.2f"))
            {
                _configService.Current.GlobalTransferOverlayScale = s;
                _configService.Save();
            }

            ImGui.SameLine();
            if (ImGui.SmallButton($"{_uiShared.L("UI.DownloadUi.526D688F", "Reset")}##globalTransfers"))
            {
                _configService.Current.GlobalTransferOverlayScale = 1.0f;
                _configService.Current.GlobalTransferOverlayX = -1f;
                _configService.Current.GlobalTransferOverlayY = -1f;
                _configService.Current.GlobalTransferOverlayRowLayout = false;
                _configService.Save();
            }

            ImGui.SameLine();
            if (ImGui.SmallButton($"{_uiShared.L("UI.DownloadUi.04E6DEF6", "Done editing")}##globalTransfers"))
            {
                _configService.Current.EditGlobalTransferOverlay = false;
                _configService.Save();
            }

            ImGui.TextDisabled(_uiShared.L("UI.DownloadUi.33045475", "Drag this window by the title bar."));
            ImGui.Separator();
        }

        // ===== Build download aggregate =====
        long dlTotalBytes = 0;
        long dlTransferredBytes = 0;
        int dlTotalFiles = 0;
        int dlTransferredFiles = 0;

        int dlInit = 0, dlQueue = 0, dlProg = 0, dlDecomp = 0;
        bool dlAllPreparing = true;

        if (_configService.Current.ShowGlobalTransferBars && haveDownloads)
        {
            foreach (var entry in currentDownloadsSnapshot)
            {
                var statuses = entry.Value.Status.Values;

                var entryTotalBytes = entry.Value.AccTotalBytes;
                foreach (var s in statuses)
                    entryTotalBytes += s.TotalBytes;

                if (entryTotalBytes <= 0 || entryTotalBytes < MinVisibleDownloadBytes)
                    continue;

                anyVisibleDl = true;

                foreach (var s in statuses)
                {
                    var remaining = Math.Max(0, s.TotalFiles - s.TransferredFiles);

                    var count = remaining;
                    if (count == 0 && s.TotalFiles == 0 && s.TransferredFiles == 0)
                        count = 1;

                    switch (s.DownloadStatus)
                    {
                        case DownloadStatus.Initializing:
                            dlInit += count;
                            break;
                        case DownloadStatus.WaitingForSlot:
                            dlQueue += count;
                            break;
                        case DownloadStatus.WaitingForQueue:
                            dlQueue += count;
                            break;
                        case DownloadStatus.Downloading:
                            dlProg += count;
                            break;
                        case DownloadStatus.Decompressing:
                            dlDecomp += Math.Max(1, count);
                            break;
                    }
                }

                dlTotalBytes += entryTotalBytes;
                dlTransferredBytes += entry.Value.AccTransferredBytes + statuses.Sum(s => s.TransferredBytes);

                dlTotalFiles += entry.Value.AccTotalFiles + statuses.Sum(s => s.TotalFiles);
                dlTransferredFiles += entry.Value.AccTransferredFiles + statuses.Sum(s => s.TransferredFiles);

                var thisPreparing = statuses.All(s =>
                    (s.DownloadStatus == DownloadStatus.Initializing
                     || s.DownloadStatus == DownloadStatus.WaitingForSlot
                     || s.DownloadStatus == DownloadStatus.WaitingForQueue)
                    && s.TransferredBytes == 0);

                dlAllPreparing &= thisPreparing;
            }
        }

        var dlPct = (dlTotalBytes <= 0) ? 0f : (float)(dlTransferredBytes / (double)dlTotalBytes);
        dlPct = Math.Clamp(dlPct, 0f, 1f);

        var dlPhase = DownloadProgressHints.GetPrimaryPhase(dlInit, dlQueue, dlProg, dlDecomp);
        var dlPhaseLabel = DownloadProgressHints.GetPhaseLabel(dlPhase);
        if (string.IsNullOrWhiteSpace(dlPhaseLabel))
            dlPhaseLabel = "Downloading";

        var dlText = dlAllPreparing
            ? dlPhaseLabel
            : $"{dlPhaseLabel}  {dlTransferredFiles}/{dlTotalFiles}  ({UiSharedService.ByteToString(dlTransferredBytes, addSuffix: false)}/{UiSharedService.ByteToString(dlTotalBytes)})";

        // ===== Build upload aggregate =====
        var uploads = haveUploads ? _fileTransferManager.GetCurrentUploadsSnapshot() : null;

        var ulTotalUploads = uploads?.Length ?? 0;
        var ulDoneUploads = 0;
        long ulTotalUploaded = 0;
        long ulTotalToUpload = 0;

        if (uploads != null)
        {
            foreach (var c in uploads)
            {
                if (c.IsTransferred) ulDoneUploads++;
                ulTotalUploaded += c.Transferred;
                ulTotalToUpload += c.Total;
            }
        }

        var ulPct = (ulTotalToUpload <= 0) ? 0f : (float)(ulTotalUploaded / (double)ulTotalToUpload);
        ulPct = Math.Clamp(ulPct, 0f, 1f);

        var ulText = $"Uploading  {ulDoneUploads}/{ulTotalUploads}  ({UiSharedService.ByteToString(ulTotalUploaded, addSuffix: false)}/{UiSharedService.ByteToString(ulTotalToUpload)})";

        // ===== Draw bars (stacked vs row) =====
        void DrawDownloadBar()
        {
            var p0 = ImGui.GetCursorScreenPos();
            var p1 = p0 + new Vector2(barW, barH);

            var mp = ImGui.GetIO().MousePos;
            var hovered = mp.X >= p0.X && mp.X <= p1.X && mp.Y >= p0.Y && mp.Y <= p1.Y;

            if (hovered && ImGui.IsMouseClicked(ImGuiMouseButton.Left))
            {
                _globalTransfersExpanded = !_globalTransfersExpanded;
            }

            DrawAetherBarComposite(dl, p0, p1, dlPct, alpha, dlAllPreparing, phase);

            if (_configService.Current.TransferBarsShowText)
            {
                GetFillRect(p0, p1, out var fs, out var fe);
                var mid = (fs + fe) * 0.5f;
                var ts = ImGui.CalcTextSize(dlText);
                UiSharedService.DrawOutlinedFont(dl, dlText, new Vector2(mid.X - ts.X / 2f, mid.Y - ts.Y / 2f),
                    UiSharedService.Color(255, 255, 255, 255), UiSharedService.Color(0, 0, 0, 220), 2);
            }


            ImGui.Dummy(new Vector2(barW, barH));

            string? hint = DownloadProgressHints.BuildPhaseList(dlInit, dlQueue, dlProg, dlDecomp);

            if (string.IsNullOrWhiteSpace(hint) && dlAllPreparing)
                hint = dlPhaseLabel;

            if (!string.IsNullOrWhiteSpace(hint))
            {
                var hintSize = ImGui.CalcTextSize(hint);

                var hintPos = new Vector2(
                    p0.X + (barW - hintSize.X) * 0.5f,
                    p1.Y + 6f
                );

                var fg = ImGui.GetForegroundDrawList();

                UiSharedService.DrawOutlinedFont(
                    fg,
                    hint,
                    hintPos,
                    UiSharedService.Color(255, 255, 255, 210),
                    UiSharedService.Color(0, 0, 0, 200),
                    2
                );
            }


            ImGui.Dummy(new Vector2(1, ImGui.GetTextLineHeight() + 10f));


        }

        void DrawUploadBar()
        {
            var p0 = ImGui.GetCursorScreenPos();
            var p1 = p0 + new Vector2(barW, barH);

            DrawUploadBarCompositeBlue(dl, p0, p1, ulPct, alpha, phase);

            if (_configService.Current.TransferBarsShowText)
            {
                GetFillRect(p0, p1, out var fs, out var fe);
                var mid = (fs + fe) * 0.5f;
                var ts = ImGui.CalcTextSize(ulText);
                UiSharedService.DrawOutlinedFont(dl, ulText, new Vector2(mid.X - ts.X / 2f, mid.Y - ts.Y / 2f),
                    UiSharedService.Color(255, 255, 255, 255), UiSharedService.Color(0, 0, 0, 220), 2);
            }

            ImGui.Dummy(new Vector2(barW, barH));
            ImGui.Dummy(new Vector2(1, ImGui.GetTextLineHeight() + 10f));

        }

        var showDlBar = _configService.Current.ShowGlobalTransferBars && (editing || anyVisibleDl);
        var showUlBar = haveUploads;

        if (_configService.Current.GlobalTransferOverlayRowLayout)
        {
            if (showDlBar)
            {
                ImGui.BeginGroup();
                DrawDownloadBar();
                ImGui.EndGroup();
            }

            if (showUlBar)
            {
                if (showDlBar) ImGui.SameLine(0, gapX);

                ImGui.BeginGroup();
                DrawUploadBar();
                ImGui.EndGroup();
            }

            ImGui.Dummy(new Vector2(1, gapY));
        }
        else
        {
            if (showDlBar)
            {
                DrawDownloadBar();
                ImGui.Dummy(new Vector2(1, gapY));
            }

            if (showUlBar)
            {
                DrawUploadBar();
                ImGui.Dummy(new Vector2(1, gapY));
            }
        }

        // ===== Details list =====
        if (_globalTransfersExpanded && currentDownloadsSnapshot.Length > 0)
        {
            var listW = _configService.Current.GlobalTransferOverlayRowLayout && showDlBar && showUlBar ? (barW * 2f + gapX) : barW;
            var listH = 170f * scale;

            var p = ImGui.GetCursorScreenPos();
            dl.AddRectFilled(p, p + new Vector2(listW, listH), UiSharedService.Color(0, 0, 0, 140), 10f);

            ImGui.BeginChild("##global_dl_list", new Vector2(listW, listH), false, ImGuiWindowFlags.NoScrollbar);

            foreach (var kv in currentDownloadsSnapshot)
            {
                var statuses = kv.Value.Status.Values;

                var totalBytes = kv.Value.AccTotalBytes;
                var transferredBytes = kv.Value.AccTransferredBytes;

                foreach (var s in statuses)
                {
                    totalBytes += s.TotalBytes;
                    transferredBytes += s.TransferredBytes;
                }

                var sQueue = 0;
                var sProg = 0;
                var sDecomp = 0;
                var sInit = 0;

                foreach (var s in statuses)
                {
                    var remaining = Math.Max(0, s.TotalFiles - s.TransferredFiles);

                    var count = remaining;
                    if (count == 0 && s.TotalFiles == 0 && s.TransferredFiles == 0)
                        count = 1;

                    switch (s.DownloadStatus)
                    {
                        case DownloadStatus.Initializing:
                            sInit += count;
                            break;

                        case DownloadStatus.WaitingForSlot:
                            sQueue += count;
                            break;

                        case DownloadStatus.WaitingForQueue:
                            sQueue += count;
                            break;

                        case DownloadStatus.Downloading:
                            sProg += count;
                            break;

                        case DownloadStatus.Decompressing:
                            sDecomp += Math.Max(1, count);
                            break;
                    }
                }


                var pct = (totalBytes <= 0) ? 0f : (float)(transferredBytes / (double)totalBytes);
                pct = Math.Clamp(pct, 0f, 1f);

                var listPhase = DownloadProgressHints.GetPrimaryPhase(sInit, sQueue, sProg, sDecomp);
                var listPhaseLabel = DownloadProgressHints.GetPhaseLabel(listPhase);
                var headerText = string.IsNullOrWhiteSpace(listPhaseLabel) ? kv.Key.Name : $"{kv.Key.Name} - {listPhaseLabel}";
                ImGui.TextUnformatted(headerText);
                ImGui.SameLine();
                ImGui.TextDisabled($"{UiSharedService.ByteToString(transferredBytes, addSuffix: false)}/{UiSharedService.ByteToString(totalBytes)}");

                ImGui.ProgressBar(pct, new Vector2(-1, MathF.Max(7f, 7f * scale)), string.Empty);
                ImGui.Dummy(new Vector2(1, 6));
            }

            ImGui.EndChild();
        }

        ImGui.End();
    }

    private Vector2 SmoothAndSnapScreen(IntPtr key, Vector2 target, float dt)
    {
        if (key == IntPtr.Zero) return new Vector2(MathF.Round(target.X), MathF.Round(target.Y));

        if (!_smoothedScreens.TryGetValue(key, out var cur))
            cur = target;

        if (Vector2.DistanceSquared(cur, target) > 2500f) 
            cur = target;

        const float lambda = 28f;
        var a = 1f - MathF.Exp(-lambda * dt);
        var next = cur + (target - cur) * a;

        _smoothedScreens[key] = next;

        return new Vector2(MathF.Round(next.X), MathF.Round(next.Y));
    }

    private void PruneSmoothedScreens(HashSet<IntPtr> keep)
    {
        if (_smoothedScreens.Count == 0) return;

        foreach (var k in _smoothedScreens.Keys.ToArray())
        {
            if (!keep.Contains(k))
                _smoothedScreens.Remove(k);
        }
    }

    private static Dictionary<string, FileDownloadStatus> SnapshotStatus(Dictionary<string, FileDownloadStatus>? src)
    {
        if (src == null || src.Count == 0)
            return new Dictionary<string, FileDownloadStatus>(StringComparer.Ordinal);

        var dst = new Dictionary<string, FileDownloadStatus>(src.Count, StringComparer.Ordinal);

        foreach (var kv in src)
        {
            var s = kv.Value;
            if (s == null) continue;

            dst[kv.Key] = new FileDownloadStatus
            {
                DownloadStatus = s.DownloadStatus,
                TotalBytes = s.TotalBytes,
                TransferredBytes = s.TransferredBytes,
                TotalFiles = s.TotalFiles,
                TransferredFiles = s.TransferredFiles
            };
        }

        return dst;
    }

    private bool TryResolveUploadingPlayerObject(Pair pair, out IGameObject? go, out IntPtr addr)
    {
        go = null;
        addr = IntPtr.Zero;

        var a = _dalamudUtilService.GetPlayerCharacterFromCachedTableByIdent(pair.Ident);

        if (a == nint.Zero)
        {
            var found = _dalamudUtilService.FindPlayerByNameHash(pair.Ident);
            if (found == default((string, nint)) || found.Address == nint.Zero)
                return false;

            a = found.Address;
        }

        addr = (IntPtr)a;

        try
        {
            for (int i = 0; i < _objectTable.Length; i++)
            {
                var o = _objectTable[i];
                if (o == null) continue;

                if ((IntPtr)o.Address != addr) continue;

                if (o.ObjectKind != Dalamud.Game.ClientState.Objects.Enums.ObjectKind.Pc)
                    return false;

                go = o;
                return true;
            }
        }
        catch
        {
            // ignore lookup errors; best effort
        }

        return false;
    }

    public override bool DrawConditions()
    {
        if (_uiShared.EditTrackerPosition) 
            return true;

        if (!_configService.Current.ShowTransferWindow
            && !_configService.Current.ShowTransferBars
            && !_configService.Current.ShowGlobalTransferBars
            && !_configService.Current.ShowUploadProgress
            && !_configService.Current.ShowUploading
            && !_configService.Current.EditGlobalTransferOverlay)
            return false;


        if (!_configService.Current.EditGlobalTransferOverlay && !_currentDownloads.Any() && !_fileTransferManager.GetCurrentUploadsSnapshot().Any() && !_pairManager.PairsWithGroups.Keys.Any(p => p.IsUploading))
            return false;

        if (!IsOpen) 
            return false;
        return true;
    }

    public override void PreDraw()
    {
        base.PreDraw();

        if (_uiShared.EditTrackerPosition)
        {
            Flags &= ~ImGuiWindowFlags.NoMove;
            Flags &= ~ImGuiWindowFlags.NoBackground;
            Flags &= ~ImGuiWindowFlags.NoInputs;
            Flags &= ~ImGuiWindowFlags.NoResize;
        }
        else
        {
            Flags |= ImGuiWindowFlags.NoMove;
            Flags |= ImGuiWindowFlags.NoBackground;
            Flags |= ImGuiWindowFlags.NoInputs;
            Flags |= ImGuiWindowFlags.NoResize;
        }

        var rows = _configService.Current.ParallelDownloads <= 0 ? 8 : _configService.Current.ParallelDownloads;
        var maxHeight = ImGui.GetTextLineHeight() * (rows + 3);
        SizeConstraints = new()
        {
            MinimumSize = new Vector2(300, maxHeight),
            MaximumSize = new Vector2(300, maxHeight),
        };
    }
}