﻿public interface IFriendResolver
{
    bool IsFriend(string playerName);
}
