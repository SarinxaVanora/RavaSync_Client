﻿namespace RavaSync.MareConfiguration.Configurations;

public interface IMareConfiguration
{
    int Version { get; set; }
}