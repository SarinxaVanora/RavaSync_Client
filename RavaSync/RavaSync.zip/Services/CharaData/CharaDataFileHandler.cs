﻿using Dalamud.Game.ClientState.Objects.SubKinds;
using K4os.Compression.LZ4.Legacy;
using RavaSync.API.Data;
using RavaSync.API.Data.Enum;
using RavaSync.API.Dto.CharaData;
using RavaSync.FileCache;
using RavaSync.PlayerData.Factories;
using RavaSync.PlayerData.Handlers;
using RavaSync.Services.CharaData;
using RavaSync.Services.CharaData.Models;
using RavaSync.Utils;
using RavaSync.WebAPI.Files;
using Microsoft.Extensions.Logging;
using System.Buffers;

namespace RavaSync.Services;

public sealed class CharaDataFileHandler : IDisposable
{
    private readonly DalamudUtilService _dalamudUtilService;
    private readonly FileCacheManager _fileCacheManager;
    private readonly FileDownloadManager _fileDownloadManager;
    private readonly FileUploadManager _fileUploadManager;
    private readonly GameObjectHandlerFactory _gameObjectHandlerFactory;
    private readonly ILogger<CharaDataFileHandler> _logger;
    private readonly MareCharaFileDataFactory _mareCharaFileDataFactory;
    private readonly PlayerDataFactory _playerDataFactory;
    private int _globalFileCounter = 0;

    public CharaDataFileHandler(ILogger<CharaDataFileHandler> logger, FileDownloadManagerFactory fileDownloadManagerFactory, FileUploadManager fileUploadManager, FileCacheManager fileCacheManager,
            DalamudUtilService dalamudUtilService, GameObjectHandlerFactory gameObjectHandlerFactory, PlayerDataFactory playerDataFactory)
    {
        _fileDownloadManager = fileDownloadManagerFactory.Create();
        _logger = logger;
        _fileUploadManager = fileUploadManager;
        _fileCacheManager = fileCacheManager;
        _dalamudUtilService = dalamudUtilService;
        _gameObjectHandlerFactory = gameObjectHandlerFactory;
        _playerDataFactory = playerDataFactory;
        _mareCharaFileDataFactory = new(fileCacheManager);
    }

    public void ComputeMissingFiles(CharaDataDownloadDto charaDataDownloadDto, out Dictionary<string, string> modPaths, out List<FileReplacementData> missingFiles)
    {
        modPaths = [];
        missingFiles = [];
        foreach (var file in charaDataDownloadDto.FileGamePaths)
        {
            var localCacheFile = _fileCacheManager.GetFileCacheByHash(file.HashOrFileSwap);
            if (localCacheFile == null)
            {
                var existingFile = missingFiles.Find(f => string.Equals(f.Hash, file.HashOrFileSwap, StringComparison.Ordinal));
                if (existingFile == null)
                {
                    missingFiles.Add(new FileReplacementData()
                    {
                        Hash = file.HashOrFileSwap,
                        GamePaths = [file.GamePath]
                    });
                }
                else
                {
                    existingFile.GamePaths = existingFile.GamePaths.Concat([file.GamePath]).ToArray();
                }
            }
            else
            {
                modPaths[file.GamePath] = localCacheFile.ResolvedFilepath;
            }
        }

        foreach (var swap in charaDataDownloadDto.FileSwaps)
        {
            modPaths[swap.GamePath] = swap.HashOrFileSwap;
        }
    }
    public async Task<CharacterData?> CreatePlayerData()
    {
        var chara = await _dalamudUtilService.GetPlayerCharacterAsync().ConfigureAwait(false);
        if (_dalamudUtilService.IsInGpose)
        {
            chara = (IPlayerCharacter?)(await _dalamudUtilService
                .GetGposeCharacterFromObjectTableByNameAsync(chara.Name.TextValue, _dalamudUtilService.IsInGpose)
                .ConfigureAwait(false));
        }

        if (chara == null)
            return null;

        using var tempHandler = await _gameObjectHandlerFactory.Create(ObjectKind.Player,
                        () => _dalamudUtilService.GetCharacterFromObjectTableByIndex(chara.ObjectIndex)?.Address ?? IntPtr.Zero,
                        isWatched: false).ConfigureAwait(false);

        PlayerData.Data.CharacterData newCdata = new();
        var fragment = await _playerDataFactory.BuildCharacterData(tempHandler, CancellationToken.None).ConfigureAwait(false);
        newCdata.SetFragment(ObjectKind.Player, fragment);

        static bool IsVfxPath(string p)
        {
            if (string.IsNullOrWhiteSpace(p)) return false;

            // Normalize slashes for safety (Penumbra usually gives / already)
            p = p.Replace("\\", "/", StringComparison.OrdinalIgnoreCase);

            return p.StartsWith("vfx/", StringComparison.OrdinalIgnoreCase)
                || p.Contains("/vfx/", StringComparison.OrdinalIgnoreCase)
                || p.StartsWith("bgcommon/vfx/", StringComparison.OrdinalIgnoreCase)
                || p.Contains("/bgcommon/vfx/", StringComparison.OrdinalIgnoreCase);
        }

        if (newCdata.FileReplacements.TryGetValue(ObjectKind.Player, out var playerData) && playerData != null)
        {
            foreach (var data in playerData.Select(g => g.GamePaths))
            {
                data.RemoveWhere(g =>
                    g.EndsWith(".scd", StringComparison.OrdinalIgnoreCase)
                    || (g.EndsWith(".avfx", StringComparison.OrdinalIgnoreCase)
                        && !(IsVfxPath(g)
                            || g.Contains("/weapon/", StringComparison.OrdinalIgnoreCase)
                            || g.Contains("/equipment/", StringComparison.OrdinalIgnoreCase)))

                    || (g.EndsWith(".atex", StringComparison.OrdinalIgnoreCase)
                        && !(IsVfxPath(g)
                            || g.Contains("/weapon/", StringComparison.OrdinalIgnoreCase)
                            || g.Contains("/equipment/", StringComparison.OrdinalIgnoreCase)))
                );
            }

            playerData.RemoveWhere(g => g.GamePaths.Count == 0);
        }

        return newCdata.ToAPI();
    }


    public void Dispose()
    {
        _fileDownloadManager.Dispose();
    }

    public async Task DownloadFilesAsync(GameObjectHandler tempHandler, List<FileReplacementData> missingFiles, Dictionary<string, string> modPaths, CancellationToken token)
    {
        await _fileDownloadManager.InitiateDownloadList(tempHandler, missingFiles, token).ConfigureAwait(false);
        await _fileDownloadManager.DownloadFiles(tempHandler, missingFiles, token).ConfigureAwait(false);
        token.ThrowIfCancellationRequested();
        foreach (var file in missingFiles.SelectMany(m => m.GamePaths, (FileEntry, GamePath) => (FileEntry.Hash, GamePath)))
        {
            var localFile = _fileCacheManager.GetFileCacheByHash(file.Hash)?.ResolvedFilepath;
            if (localFile == null)
            {
                throw new FileNotFoundException("File not found locally.");
            }
            modPaths[file.GamePath] = localFile;
        }
    }

    public Task<(MareCharaFileHeader loadedCharaFile, long expectedLength)> LoadCharaFileHeader(string filePath)
    {
        try
        {
            using var unwrapped = File.OpenRead(filePath);
            using var lz4Stream = new LZ4Stream(unwrapped, LZ4StreamMode.Decompress, LZ4StreamFlags.HighCompression);
            using var reader = new BinaryReader(lz4Stream);
            var loadedCharaFile = MareCharaFileHeader.FromBinaryReader(filePath, reader);

            _logger.LogInformation("Read RavaSync Chara File");
            _logger.LogInformation("Version: {ver}", (loadedCharaFile?.Version ?? -1));
            long expectedLength = 0;
            if (loadedCharaFile != null)
            {
                _logger.LogTrace("Data");
                foreach (var item in loadedCharaFile.CharaFileData.FileSwaps)
                {
                    foreach (var gamePath in item.GamePaths)
                    {
                        _logger.LogTrace("Swap: {gamePath} => {fileSwapPath}", gamePath, item.FileSwapPath);
                    }
                }

                var itemNr = 0;
                foreach (var item in loadedCharaFile.CharaFileData.Files)
                {
                    itemNr++;
                    expectedLength += item.Length;
                    foreach (var gamePath in item.GamePaths)
                    {
                        _logger.LogTrace("File {itemNr}: {gamePath} = {len}", itemNr, gamePath, item.Length.ToByteString());
                    }
                }

                _logger.LogInformation("Expected length: {expected}", expectedLength.ToByteString());
            }
            else
            {
                throw new InvalidOperationException("MCDF Header was null");
            }
            return Task.FromResult((loadedCharaFile, expectedLength));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not parse MCDF header of file {file}", filePath);
            throw;
        }
    }

    public Dictionary<string, string> McdfExtractFiles(MareCharaFileHeader? charaFileHeader, long expectedLength, List<string> extractedFiles)
    {
        if (charaFileHeader == null) return [];

        using var lz4Stream = new LZ4Stream(File.OpenRead(charaFileHeader.FilePath), LZ4StreamMode.Decompress, LZ4StreamFlags.HighCompression);
        using var reader = new BinaryReader(lz4Stream);
        MareCharaFileHeader.AdvanceReaderToData(reader);

        long totalRead = 0;
        Dictionary<string, string> gamePathToFilePath = new(StringComparer.Ordinal);
        var buffer = ArrayPool<byte>.Shared.Rent(128 * 1024);
        try
        {
            foreach (var fileData in charaFileHeader.CharaFileData.Files)
            {
                var fileName = Path.Combine(_fileCacheManager.CacheFolder, "mare_" + _globalFileCounter++ + ".tmp");
                extractedFiles.Add(fileName);
                var remaining = fileData.Length;
                using var fs = File.OpenWrite(fileName);
                _logger.LogTrace("Reading {length} of {fileName}", fileData.Length.ToByteString(), fileName);
                while (remaining > 0)
                {
                    var chunkSize = Math.Min(buffer.Length, remaining);
                    var read = reader.Read(buffer, 0, chunkSize);
                    if (read <= 0)
                    {
                        throw new EndOfStreamException($"Unexpected EOF while extracting MCDF for hash {fileData.Hash}");
                    }

                    fs.Write(buffer, 0, read);
                    remaining -= read;
                    totalRead += read;
                }

                fs.Flush();
                foreach (var path in fileData.GamePaths)
                {
                    gamePathToFilePath[path] = fileName;
                    _logger.LogTrace("{path} => {fileName} [{hash}]", path, fileName, fileData.Hash);
                }
                _logger.LogTrace("Read {read}/{expected} bytes", totalRead.ToByteString(), expectedLength.ToByteString());
            }
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }

        return gamePathToFilePath;
    }

    public async Task UpdateCharaDataAsync(CharaDataExtendedUpdateDto updateDto)
    {
        var data = await CreatePlayerData().ConfigureAwait(false);

        if (data != null)
        {
            var hasGlamourerData = data.GlamourerData.TryGetValue(ObjectKind.Player, out var playerDataString);
            if (!hasGlamourerData) updateDto.GlamourerData = null;
            else updateDto.GlamourerData = playerDataString;

            var hasCustomizeData = data.CustomizePlusData.TryGetValue(ObjectKind.Player, out var customizeDataString);
            if (!hasCustomizeData) updateDto.CustomizeData = null;
            else updateDto.CustomizeData = customizeDataString;

            updateDto.ManipulationData = data.ManipulationData;

            var hasFiles = data.FileReplacements.TryGetValue(ObjectKind.Player, out var fileReplacements);
            if (!hasFiles)
            {
                updateDto.FileGamePaths = [];
                updateDto.FileSwaps = [];
            }
            else
            {
                updateDto.FileGamePaths = [.. fileReplacements!.Where(u => string.IsNullOrEmpty(u.FileSwapPath)).SelectMany(u => u.GamePaths, (file, path) => new GamePathEntry(file.Hash, path))];
                updateDto.FileSwaps = [.. fileReplacements!.Where(u => !string.IsNullOrEmpty(u.FileSwapPath)).SelectMany(u => u.GamePaths, (file, path) => new GamePathEntry(file.FileSwapPath, path))];
            }
        }
    }

    internal async Task SaveCharaFileAsync(string description, string filePath)
    {
        var tempFilePath = filePath + ".tmp";

        try
        {
            var data = await CreatePlayerData().ConfigureAwait(false);
            if (data == null) return;

            var mareCharaFileData = _mareCharaFileDataFactory.Create(description, data);
            MareCharaFileHeader output = new(MareCharaFileHeader.CurrentVersion, mareCharaFileData);
            var totalGamePaths = output.CharaFileData.Files.Sum(f => f.GamePaths.Count()) + output.CharaFileData.FileSwaps.Sum(f => f.GamePaths.Count());
            _logger.LogInformation("Exporting MCDF with {fileCount} embedded files, {swapCount} file swaps, {gamePathCount} game paths", output.CharaFileData.Files.Count, output.CharaFileData.FileSwaps.Count, totalGamePaths);

            using var fs = new FileStream(tempFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
            using var lz4 = new LZ4Stream(fs, LZ4StreamMode.Compress, LZ4StreamFlags.HighCompression);
            using var writer = new BinaryWriter(lz4);
            output.WriteToStream(writer);

            var buffer = ArrayPool<byte>.Shared.Rent(128 * 1024);
            try
            {
                foreach (var item in output.CharaFileData.Files)
                {
                    var file = _fileCacheManager.GetFileCacheByHash(item.Hash);
                    if (file == null || string.IsNullOrWhiteSpace(file.ResolvedFilepath) || !File.Exists(file.ResolvedFilepath))
                    {
                        throw new FileNotFoundException($"MCDF export source missing for hash {item.Hash}", file?.ResolvedFilepath);
                    }

                    _logger.LogDebug("Saving to MCDF: {hash}:{file}", item.Hash, file.ResolvedFilepath);
                    _logger.LogDebug("	Associated GamePaths:");
                    foreach (var path in item.GamePaths)
                    {
                        _logger.LogDebug("	{path}", path);
                    }

                    await using var fsRead = File.OpenRead(file.ResolvedFilepath);
                    var remaining = item.Length;
                    while (remaining > 0)
                    {
                        var read = await fsRead.ReadAsync(buffer.AsMemory(0, Math.Min(buffer.Length, remaining))).ConfigureAwait(false);
                        if (read <= 0)
                        {
                            throw new EndOfStreamException($"Unexpected EOF while exporting MCDF for hash {item.Hash}");
                        }

                        writer.Write(buffer, 0, read);
                        remaining -= read;
                    }
                }
            }
            finally
            {
                ArrayPool<byte>.Shared.Return(buffer);
            }

            writer.Flush();
            await lz4.FlushAsync().ConfigureAwait(false);
            await fs.FlushAsync().ConfigureAwait(false);
            fs.Close();
            File.Move(tempFilePath, filePath, true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failure Saving RavaSync Chara File, deleting output");
            File.Delete(tempFilePath);
        }
    }

    internal async Task<List<string>> UploadFiles(List<string> fileList, ValueProgress<string> uploadProgress, CancellationToken token)
    {
        return await _fileUploadManager.UploadFiles(fileList, uploadProgress, token).ConfigureAwait(false);
    }
}
