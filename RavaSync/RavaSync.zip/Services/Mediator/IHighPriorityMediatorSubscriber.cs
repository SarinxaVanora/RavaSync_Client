﻿namespace RavaSync.Services.Mediator;

public interface IHighPriorityMediatorSubscriber : IMediatorSubscriber { }