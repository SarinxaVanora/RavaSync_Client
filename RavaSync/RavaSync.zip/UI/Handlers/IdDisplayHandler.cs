using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.Colors;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Utility.Raii;
using RavaSync.API.Dto.Group;
using RavaSync.MareConfiguration;
using RavaSync.PlayerData.Pairs;
using RavaSync.Services.Mediator;
using RavaSync.Services.ServerConfiguration;
using RavaSync.UI;
using RavaSync.WebAPI.Files.Models;
using System.Numerics;

namespace RavaSync.UI.Handlers;

public class IdDisplayHandler
{
    private static string FormatTrianglesThousands(long triangles)
    {
        if (triangles <= 0) return "0K";
        long roundedThousands = (long)Math.Round(triangles / 1000d, MidpointRounding.AwayFromZero);
        return $"{roundedThousands:N0}K";
    }

    private readonly MareConfigService _mareConfigService;
    private readonly MareMediator _mediator;
    private readonly ServerConfigurationManager _serverManager;
    private readonly UiSharedService _uiShared;
    private readonly Dictionary<string, bool> _showIdForEntry = new(StringComparer.Ordinal);
    private string _editComment = string.Empty;
    private string _editEntry = string.Empty;
    private bool _editIsUid = false;
    private string _lastMouseOverUid = string.Empty;
    private bool _popupShown = false;
    private DateTime? _popupTime;

    public IdDisplayHandler(MareMediator mediator, ServerConfigurationManager serverManager, MareConfigService mareConfigService, UiSharedService uiShared)
    {
        _mediator = mediator;
        _serverManager = serverManager;
        _mareConfigService = mareConfigService;
        _uiShared = uiShared;
    }

    public void DrawGroupText(string id, GroupFullInfoDto group, float textPosX, Func<float> editBoxWidth)
    {
        ImGui.SameLine(textPosX);
        (bool textIsUid, string playerText) = GetGroupText(group);
        if (!string.Equals(_editEntry, group.GID, StringComparison.Ordinal))
        {
            ImGui.AlignTextToFramePadding();

            using (ImRaii.PushFont(UiBuilder.MonoFont, textIsUid))
                ImGui.TextUnformatted(playerText);

            if (ImGui.IsItemClicked(ImGuiMouseButton.Left))
            {
                var prevState = textIsUid;
                if (_showIdForEntry.ContainsKey(group.GID))
                {
                    prevState = _showIdForEntry[group.GID];
                }
                _showIdForEntry[group.GID] = !prevState;
            }

            if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
            {
                if (_editIsUid)
                {
                    _serverManager.SetNoteForUid(_editEntry, _editComment, save: true);
                }
                else
                {
                    _serverManager.SetNoteForGid(_editEntry, _editComment, save: true);
                }

                _editComment = _serverManager.GetNoteForGid(group.GID) ?? string.Empty;
                _editEntry = group.GID;
                _editIsUid = false;
            }
        }
        else
        {
            ImGui.AlignTextToFramePadding();

            ImGui.SetNextItemWidth(editBoxWidth.Invoke());
            if (ImGui.InputTextWithHint("", _uiShared.L("UI.IdDisplayHandler.965c6daa", "Name/Notes"), ref _editComment, 255, ImGuiInputTextFlags.EnterReturnsTrue))
            {
                _serverManager.SetNoteForGid(group.GID, _editComment, save: true);
                _editEntry = string.Empty;
            }

            if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
            {
                _editEntry = string.Empty;
            }
            UiSharedService.AttachToolTip(_uiShared.L("UI.IdDisplayHandler.868a0c06", "Hit ENTER to save\nRight click to cancel"));
        }
    }

    public void DrawPairText(string id, Pair pair, float textPosX, Func<float> editBoxWidth)
    {
        ImGui.SameLine(textPosX);
        (bool textIsUid, string playerText) = GetPlayerText(pair);
        if (!string.Equals(_editEntry, pair.UserData.UID, StringComparison.Ordinal))
        {

            // ---- two-line cell (name + VRAM) ----

            // DO NOT center: we'll control Y manually
            float startY = ImGui.GetCursorPosY();
            float line = ImGui.GetTextLineHeight();
            float spacing = ImGui.GetStyle().ItemSpacing.Y;
            float twoLineMin = line * 2f + spacing * 0.5f;

            // 1) first line (name / uid / note)
            ImGui.SetCursorPosY(startY);
            using (ImRaii.PushFont(UiBuilder.MonoFont, textIsUid))
                ImGui.TextUnformatted(playerText);

            // 2) second line (VRAM) — always reserve the second row so height is consistent
            ImGui.SetCursorPosX(textPosX);
            ImGui.SetCursorPosY(startY + line + spacing * 0.25f);

            // Compact pair list deliberately uses tiny transfer hints only: UP/DL.
            // The full overlay/world bars keep the human-readable phase labels.
            var dl = pair.CurrentDownloadSummary;
            if (pair.IsUploading || (dl != null && dl.HasAny))
            {
                var phase = DownloadProgressHints.GetPrimaryPhase(pair.CurrentDownloadStatus?.Values);
                var label = DownloadProgressHints.GetCompactPairTransferLabel(pair.IsUploading, phase);
                if (string.IsNullOrWhiteSpace(label) && dl != null && dl.HasAny)
                    label = "DL";

                bool uploadStyle = pair.IsUploading;
                long totalBytes = dl?.TotalBytes ?? 0;
                long transferredBytes = dl?.TransferredBytes ?? 0;
                int totalFiles = dl?.TotalFiles ?? 0;
                int transferredFiles = dl?.TransferredFiles ?? 0;

                string text;

                if (!uploadStyle && totalBytes > 0)
                {
                    var pct = (double)transferredBytes * 100d / (double)totalBytes;
                    text = $"{label}: {UiSharedService.ByteToString(transferredBytes, addSuffix: true)}/{UiSharedService.ByteToString(totalBytes, addSuffix: true)} ({pct:0}%)";
                }
                else if (!uploadStyle && totalFiles > 0)
                {
                    var pct = (double)transferredFiles * 100d / (double)totalFiles;
                    text = $"{label}: {transferredFiles}/{totalFiles} files ({pct:0}%)";
                }
                else
                {
                    text = label;
                }

                ImGui.PushStyleColor(ImGuiCol.Text, uploadStyle ? ImGuiColors.DalamudYellow : ImGuiColors.ParsedBlue);
                ImGui.TextUnformatted(text);
                ImGui.PopStyleColor();
            }
            else if (pair.LastAppliedApproximateVRAMBytes >= 0)
            {
                static string NoDot00(string s)
                {
                    if (string.IsNullOrEmpty(s)) return s;

                    var space = s.IndexOf(' ');
                    if (space <= 0) return s;

                    var num = s[..space];
                    var unit = s[space..];

                    if (num.EndsWith(".00", StringComparison.Ordinal) || num.EndsWith(",00", StringComparison.Ordinal))
                        return num[..^3] + unit;

                    return s;
                }

                ImGui.PushStyleColor(ImGuiCol.Text, ImGuiColors.DalamudGrey);

                var roundedBytes = (long)(Math.Round(pair.LastAppliedApproximateVRAMBytes / 1048576d) * 1048576d);
                var vramText = NoDot00(UiSharedService.ByteToString(roundedBytes, addSuffix: true));
                var trisText = pair.LastAppliedDataTris > 0
                    ? FormatTrianglesThousands(pair.LastAppliedDataTris)
                    : "—";

                var line1 = $"VRAM: {vramText} | Tris: {trisText}";

                float regionW = ImGui.GetContentRegionAvail().X;
                float lineH = ImGui.GetTextLineHeight();
                var start = ImGui.GetCursorScreenPos();

                ImGui.InvisibleButton("##pair_stats_line", new Vector2(MathF.Max(1f, regionW), lineH));

                float padX = 2f * ImGuiHelpers.GlobalScale;
                float innerW = MathF.Max(1f, regionW - (padX * 2f));

                float textW = ImGui.CalcTextSize(line1).X;
                float totalW = textW;

                // Keep it readable but allow compact shrink
                float scale = totalW > 0f ? MathF.Min(1f, innerW / totalW) : 1f;
                scale = MathF.Max(0.78f, scale);

                var font = ImGui.GetFont();
                float fontSize = ImGui.GetFontSize() * scale;

                float x = start.X + padX;
                float y = start.Y + (lineH - fontSize) * 0.5f;

                var dl1 = ImGui.GetWindowDrawList();
                var rMin = start;
                var rMax = start + new Vector2(regionW, lineH);

                dl1.PushClipRect(rMin, rMax, true);
                dl1.AddText(font, fontSize, new Vector2(x, y), ImGui.GetColorU32(ImGuiCol.Text), line1);

                dl1.PopClipRect();

                ImGui.PopStyleColor();
            }
            else
            {
                ImGui.Dummy(new(0, line));
            }


            // 3) ensure the cell height is at least two lines so the whole table row grows
            float used = ImGui.GetCursorPosY() - startY;
            if (used < twoLineMin)
            {
                ImGui.SetCursorPosX(textPosX);
                ImGui.Dummy(new(0, twoLineMin - used));
            }

            if (ImGui.IsItemHovered())
            {
                if (!string.Equals(_lastMouseOverUid, id))
                {
                    _popupTime = DateTime.UtcNow.AddSeconds(_mareConfigService.Current.ProfileDelay);
                }

                _lastMouseOverUid = id;

                if (_popupTime > DateTime.UtcNow || !_mareConfigService.Current.ProfilesShow)
                {
                    ImGui.SetTooltip(_uiShared.L("UI.IdDisplayHandler.c8d0f471", "Left click to switch between UID display and nick") + Environment.NewLine
                        + "Right click to change nick for " + pair.UserData.AliasOrUID + Environment.NewLine
                        + _uiShared.L("UI.IdDisplayHandler.2f20db7a", "Middle Mouse Button to open their profile in a separate window"));
                }
                else if (_popupTime < DateTime.UtcNow && !_popupShown)
                {
                    _popupShown = true;
                    _mediator.Publish(new ProfilePopoutToggle(pair));
                }
            }
            else
            {
                if (string.Equals(_lastMouseOverUid, id))
                {
                    _mediator.Publish(new ProfilePopoutToggle(Pair: null));
                    _lastMouseOverUid = string.Empty;
                    _popupShown = false;
                }
            }

            if (ImGui.IsItemClicked(ImGuiMouseButton.Left))
            {
                var prevState = textIsUid;
                if (_showIdForEntry.ContainsKey(pair.UserData.UID))
                {
                    prevState = _showIdForEntry[pair.UserData.UID];
                }
                _showIdForEntry[pair.UserData.UID] = !prevState;
            }

            if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
            {
                if (_editIsUid)
                {
                    _serverManager.SetNoteForUid(_editEntry, _editComment, save: true);
                }
                else
                {
                    _serverManager.SetNoteForGid(_editEntry, _editComment, save: true);
                }

                _editComment = pair.GetNote() ?? string.Empty;
                _editEntry = pair.UserData.UID;
                _editIsUid = true;
            }

            if (ImGui.IsItemClicked(ImGuiMouseButton.Middle))
            {
                _mediator.Publish(new ProfileOpenStandaloneMessage(pair));
            }
        }
        else
        {
            ImGui.AlignTextToFramePadding();

            ImGui.SetNextItemWidth(editBoxWidth.Invoke());
            if (ImGui.InputTextWithHint("##" + pair.UserData.UID, _uiShared.L("UI.IdDisplayHandler.a3b5e868", "Nick/Notes"), ref _editComment, 255, ImGuiInputTextFlags.EnterReturnsTrue))
            {
                _serverManager.SetNoteForUid(pair.UserData.UID, _editComment);
                _serverManager.SaveNotes();
                _editEntry = string.Empty;
            }

            if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
            {
                _editEntry = string.Empty;
            }
            UiSharedService.AttachToolTip(_uiShared.L("UI.IdDisplayHandler.868a0c06", "Hit ENTER to save\nRight click to cancel"));
        }
    }

    public (bool isGid, string text) GetGroupText(GroupFullInfoDto group)
    {
        var textIsGid = true;
        bool showUidInsteadOfName = ShowGidInsteadOfName(group);
        string? groupText = _serverManager.GetNoteForGid(group.GID);
        if (!showUidInsteadOfName && groupText != null)
        {
            if (string.IsNullOrEmpty(groupText))
            {
                groupText = group.GroupAliasOrGID;
            }
            else
            {
                textIsGid = false;
            }
        }
        else
        {
            groupText = group.GroupAliasOrGID;
        }

        return (textIsGid, groupText!);
    }

    public (bool isUid, string text) GetPlayerText(Pair pair)
    {
        var textIsUid = true;
        bool showUidInsteadOfName = ShowUidInsteadOfName(pair);
        string? playerText = _serverManager.GetNoteForUid(pair.UserData.UID);
        if (!showUidInsteadOfName && playerText != null)
        {
            if (string.IsNullOrEmpty(playerText))
            {
                playerText = pair.UserData.AliasOrUID;
            }
            else
            {
                textIsUid = false;
            }
        }
        else
        {
            playerText = pair.UserData.AliasOrUID;
        }

        if (_mareConfigService.Current.ShowCharacterNameInsteadOfNotesForVisible && pair.IsVisible && !showUidInsteadOfName)
        {
            playerText = pair.PlayerName;
            textIsUid = false;
            if (_mareConfigService.Current.PreferNotesOverNamesForVisible)
            {
                var note = pair.GetNote();
                if (note != null)
                {
                    playerText = note;
                }
            }
        }

        return (textIsUid, playerText!);
    }

    private List<(FontAwesomeIcon Icon, uint Color, string Tooltip)> GetActiveResourceIconInfos(Pair pair)
    {
        var iconInfos = new List<(FontAwesomeIcon Icon, uint Color, string Tooltip)>();

        if (pair.IsPlayingSound)
            iconInfos.Add((FontAwesomeIcon.Music, ImGui.GetColorU32(ImGuiColors.ParsedBlue), _uiShared.L("UI.IdDisplayHandler.Icon.PlayingSound", "Currently playing synced sound")));

        return iconInfos;
    }


    private void DrawInlineActiveResourceIcons(List<(FontAwesomeIcon Icon, uint Color, string Tooltip)> iconInfos)
    {
        if (iconInfos.Count == 0)
            return;

        float iconSpacing = ImGui.GetStyle().ItemInnerSpacing.X * 0.75f;

        using (_uiShared.IconFont.Push())
        {
            for (var i = 0; i < iconInfos.Count; i++)
            {
                if (i > 0)
                    ImGui.SameLine(0f, iconSpacing);

                var iconText = iconInfos[i].Icon.ToIconString();
                var size = ImGui.CalcTextSize(iconText);
                var pos = ImGui.GetCursorScreenPos();

                ImGui.InvisibleButton("##inline_active_resource_icon_" + i, size);
                ImGui.GetWindowDrawList().AddText(pos, iconInfos[i].Color, iconText);

                if (ImGui.IsItemHovered())
                    UiSharedService.AttachToolTip(iconInfos[i].Tooltip);
            }
        }
    }

    internal void Clear()
    {
        _editEntry = string.Empty;
        _editComment = string.Empty;
    }

    internal void OpenProfile(Pair entry)
    {
        _mediator.Publish(new ProfileOpenStandaloneMessage(entry));
    }

    private bool ShowGidInsteadOfName(GroupFullInfoDto group)
    {
        _showIdForEntry.TryGetValue(group.GID, out var showidInsteadOfName);

        return showidInsteadOfName;
    }

    private bool ShowUidInsteadOfName(Pair pair)
    {
        _showIdForEntry.TryGetValue(pair.UserData.UID, out var showidInsteadOfName);

        return showidInsteadOfName;
    }
}