﻿using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.Colors;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Utility.Raii;
using Dalamud.Plugin.Services;
using Dalamud.Utility;
using RavaSync.FileCache;
using RavaSync.Localization;
using RavaSync.MareConfiguration;
using RavaSync.MareConfiguration.Models;
using RavaSync.Services;
using RavaSync.Services.Mediator;
using RavaSync.Services.ServerConfiguration;
using RavaSync.WebAPI.SignalR.Utils;
using Microsoft.Extensions.Logging;
using System.Numerics;
using System.Text.RegularExpressions;
using static RavaSync.WebAPI.SignalR.TokenProvider;

namespace RavaSync.UI;

public partial class IntroUi : WindowMediatorSubscriberBase
{
    private readonly MareConfigService _configService;
    private readonly CacheMonitor _cacheMonitor;
    private readonly Dictionary<string, string> _languages = new(StringComparer.Ordinal)
{
    { "English", "en" },
    { "Deutsch", "de" },
    { "Français", "fr" },

    { "Español", "es" },
    { "العربية", "ar" },
    { "日本語", "ja" },
    { "中文", "zh" },
    { "한국어", "ko" },
    { "Русский", "ru" },

    // funsies
    { "Pirate", "pirate" },
    { "Olde English", "olde" },
};
    private readonly ServerConfigurationManager _serverConfigurationManager;
    private readonly DalamudUtilService _dalamudUtilService;
    private readonly UiSharedService _uiShared;
    private int _currentLanguage;
    private bool _readFirstPage;

    private string _secretKey = string.Empty;
    private string _timeoutLabel = string.Empty;
    private Task? _timeoutTask;
    private string[]? _tosParagraphs;
    private bool _useLegacyLogin = true;

    private bool _creatingSecret = false;
    private string _regSecret = string.Empty;
    private string _regUid = string.Empty;
    private string? _regError = null;
    private bool _showSecret = false;
    private sealed record CreateClientSecretResponse(string Uid, string Secret);


    public IntroUi(ILogger<IntroUi> logger, UiSharedService uiShared, MareConfigService configService,
        CacheMonitor fileCacheManager, ServerConfigurationManager serverConfigurationManager, MareMediator mareMediator,
        PerformanceCollectorService performanceCollectorService, DalamudUtilService dalamudUtilService) : base(logger, mareMediator, "RavaSync Setup", performanceCollectorService)
    {
        _uiShared = uiShared;
        _configService = configService;
        _cacheMonitor = fileCacheManager;
        _serverConfigurationManager = serverConfigurationManager;
        _dalamudUtilService = dalamudUtilService;
        IsOpen = false;
        ShowCloseButton = false;
        RespectCloseHotkey = false;

        SizeConstraints = new WindowSizeConstraints()
        {
            MinimumSize = new Vector2(600, 400),
            MaximumSize = new Vector2(600, 2000),
        };

        GetToSLocalization();

        Mediator.Subscribe<SwitchToMainUiMessage>(this, (_) => IsOpen = false);
        Mediator.Subscribe<SwitchToIntroUiMessage>(this, (_) =>
        {
            _configService.Current.UseCompactor = !dalamudUtilService.IsWine;
            IsOpen = true;
        });
    }

    private int _prevIdx = -1;

    protected override void DrawInternal()
    {
        if (_uiShared.IsInGpose) return;

        if (!_configService.Current.AcceptedAgreement && !_readFirstPage)
        {
            _uiShared.BigText("Welcome to RavaSync");
            ImGui.Separator();
            UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.078f77a1", "RavaSync is a plugin that will replicate your full current character state including all Penumbra mods to other paired users. ") +
                              "Note that you will have to have Penumbra as well as Glamourer installed to use this plugin.");
            UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.c7206414", "We will have to setup a few things first before you can start using this plugin. Click on next to continue."));

            UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.681f133c", "Note: Any modifications you have applied through anything but Penumbra cannot be shared and your character state on other clients ") +
                                 "might look broken because of this or others players mods might not apply on your end altogether. " +
                                 "If you want to use this plugin you will have to move your mods to Penumbra.", ImGuiColors.DalamudYellow);
            if (!_uiShared.DrawOtherPluginState()) return;
            ImGui.Separator();
            if (ImGui.Button($"{_uiShared.L("UI.IntroUI.10AC3D04", "Next")}##toAgreement"))
            {
                _readFirstPage = true;
#if !DEBUG
                _timeoutTask = Task.Run(async () =>
                {
                    for (int i = 10; i > 0; i--)
                    {
                        _timeoutLabel = $"{Strings.ToS.ButtonWillBeAvailableIn} {i}s";
                        await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(false);
                    }
                });
#else
                _timeoutTask = Task.CompletedTask;
#endif
            }
        }
        else if (!_configService.Current.AcceptedAgreement && _readFirstPage)
        {
            Vector2 textSize;
            using (_uiShared.UidFont.Push())
            {
                textSize = ImGui.CalcTextSize(Strings.ToS.LanguageLabel);
                ImGui.TextUnformatted(Strings.ToS.AgreementLabel);
            }

            ImGui.SameLine();
            var languageSize = ImGui.CalcTextSize(Strings.ToS.LanguageLabel);
            ImGui.SetCursorPosX(ImGui.GetWindowContentRegionMax().X - ImGui.GetWindowContentRegionMin().X - languageSize.X - 80);
            ImGui.SetCursorPosY(ImGui.GetCursorPosY() + textSize.Y / 2 - languageSize.Y / 2);

            ImGui.TextUnformatted(Strings.ToS.LanguageLabel);
            ImGui.SameLine();
            ImGui.SetCursorPosY(ImGui.GetCursorPosY() + textSize.Y / 2 - (languageSize.Y + ImGui.GetStyle().FramePadding.Y) / 2);
            ImGui.SetNextItemWidth(80);
            if (ImGui.Combo("", ref _currentLanguage, _languages.Keys.ToArray(), _languages.Count))
            {
                GetToSLocalization(_currentLanguage);
            }

            ImGui.Separator();
            ImGui.SetWindowFontScale(1.5f);
            string readThis = Strings.ToS.ReadLabel;
            textSize = ImGui.CalcTextSize(readThis);
            ImGui.SetCursorPosX(ImGui.GetWindowSize().X / 2 - textSize.X / 2);
            UiSharedService.ColorText(readThis, ImGuiColors.DalamudRed);
            ImGui.SetWindowFontScale(1.0f);
            ImGui.Separator();

            UiSharedService.TextWrapped(_tosParagraphs![0]);
            UiSharedService.TextWrapped(_tosParagraphs![1]);
            UiSharedService.TextWrapped(_tosParagraphs![2]);
            UiSharedService.TextWrapped(_tosParagraphs![3]);
            UiSharedService.TextWrapped(_tosParagraphs![4]);
            UiSharedService.TextWrapped(_tosParagraphs![5]);

            ImGui.Separator();
            if (_timeoutTask?.IsCompleted ?? true)
            {
                if (ImGui.Button(Strings.ToS.AgreeLabel + "##toSetup"))
                {
                    _configService.Current.AcceptedAgreement = true;
                    _configService.Save();
                }
            }
            else
            {
                UiSharedService.TextWrapped(_timeoutLabel);
            }
        }
        else if (_configService.Current.AcceptedAgreement
                 && (string.IsNullOrEmpty(_configService.Current.CacheFolder)
                     || !_configService.Current.InitialScanComplete
                     || !Directory.Exists(_configService.Current.CacheFolder)))
        {
            using (_uiShared.UidFont.Push())
                ImGui.TextUnformatted(_uiShared.L("UI.IntroUI.e19b0c3e", "File Storage Setup"));

            ImGui.Separator();

            if (!_uiShared.HasValidPenumbraModPath)
            {
                UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.8ff78c5c", "You do not have a valid Penumbra path set. Open Penumbra and set up a valid path for the mod directory."), ImGuiColors.DalamudRed);
            }
            else
            {
                UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.c59ddf7c", "To not unnecessary download files already present on your computer, RavaSync will have to scan your Penumbra mod directory. ") +
                                     "Additionally, a local storage folder must be set where RavaSync will download other character files to. " +
                                     "Once the storage folder is set and the scan complete, this page will automatically forward to registration at a service.");
                UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.6126f05a", "Note: The initial scan, depending on the amount of mods you have, might take a while. Please wait until it is completed."));
                UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.0da4157b", "Warning: once past this step you should not delete the FileCache.csv of RavaSync in the Plugin Configurations folder of Dalamud. ") +
                                          "Otherwise on the next launch a full re-scan of the file cache database will be initiated.", ImGuiColors.DalamudYellow);
                UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.909f1477", "Warning: if the scan is hanging and does nothing for a long time, chances are high your Penumbra folder is not set up properly."), ImGuiColors.DalamudYellow);
                _uiShared.DrawCacheDirectorySetting();
            }

            if (!_cacheMonitor.IsScanRunning && !string.IsNullOrEmpty(_configService.Current.CacheFolder) && _uiShared.HasValidPenumbraModPath && Directory.Exists(_configService.Current.CacheFolder))
            {
                if (ImGui.Button($"{_uiShared.L("UI.IntroUI.9E4D6233", "Start Scan")}##startScan"))
                {
                    _cacheMonitor.InvokeScan();
                }
            }
            else
            {
                _uiShared.DrawFileScanState();
            }
            if (!_dalamudUtilService.IsWine)
            {
                var useFileCompactor = _configService.Current.UseCompactor;
                if (ImGui.Checkbox(_uiShared.L("UI.IntroUI.b4a7e07f", "Use File Compactor"), ref useFileCompactor))
                {
                    _configService.Current.UseCompactor = useFileCompactor;
                    _configService.Save();
                }
                UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.29a09842", "The File Compactor can save a tremendeous amount of space on the hard disk for downloads. It will incur a minor CPU penalty on download but can speed up ") +
                    "loading of other characters. It is recommended to keep it enabled. You can change this setting later anytime in settings.", ImGuiColors.DalamudYellow);
            }
        }
        else if (!_uiShared.ApiController.ServerAlive)
        {
            using (_uiShared.UidFont.Push())
                ImGui.TextUnformatted(_uiShared.L("UI.IntroUI.3a85076c", "Service Registration"));
            ImGui.Separator();
            UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.4cfa8c88", "To be able to use RavaSync you will have to register an account."));
            UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.946cbbca", "You will see a funny line of text - this is what you should paste into any secret key labled box."));
            UiSharedService.DistanceSeparator();

            UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.3f67db59", "Once you have registered you can connect to the service using the tools provided below."));

            int serverIdx = 0;
            var selectedServer = _serverConfigurationManager.GetServerByIndex(serverIdx);

            using (var node = ImRaii.TreeNode("Advanced Options"))
            {
                if (node)
                {
                    serverIdx = _uiShared.DrawServiceSelection(selectOnChange: true, showConnect: false);
                    if (serverIdx != _prevIdx)
                    {
                        _uiShared.ResetOAuthTasksState();
                        _prevIdx = serverIdx;
                    }

                    selectedServer = _serverConfigurationManager.GetServerByIndex(serverIdx);
                    _useLegacyLogin = true;

                    //if (ImGui.Checkbox(_uiShared.L("UI.IntroUI.8a52bb21", "Use Legacy Login with Secret Key"), ref _useLegacyLogin))
                    //{
                        _serverConfigurationManager.GetServerByIndex(serverIdx).UseOAuth2 = false;
                        _serverConfigurationManager.Save();
                    //}
                }
            }

            UiSharedService.DistanceSeparator();
            UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.C63AC5A0", "If you donât have a secret yet, generate one here and copy it into the box below."));

            using (var row = ImRaii.Group())
            {
                if (!_creatingSecret)
                {
                    if (ImGui.Button(_uiShared.L("UI.IntroUI.d672995a", "Register")))
                    {
                        _creatingSecret = true;
                        _regError = null;
                        _regUid = _regSecret = string.Empty;

                        var server = selectedServer; // keep current selection
                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                // Figure out the base URL of this server
                                var baseUrl = server.ServerUri?.TrimEnd('/') ?? _serverConfigurationManager.GetServerByIndex(0).ServerUri?.TrimEnd('/');
                                if (string.IsNullOrWhiteSpace(baseUrl))
                                    throw new InvalidOperationException("No server base URL is configured.");

                                using var http = new HttpClient();
                                http.Timeout = TimeSpan.FromSeconds(30);

                                var resp = await http.PostAsync($"{baseUrl}/auth/createClientSecret", content: null).ConfigureAwait(false);
                                resp.EnsureSuccessStatusCode();

                                var json = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
                                var data = System.Text.Json.JsonSerializer.Deserialize<CreateClientSecretResponse>(
                                    json,
                                    new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                                if (data is null || string.IsNullOrWhiteSpace(data.Secret))
                                    throw new InvalidOperationException("Server returned no secret. Check auth service logs.");

                                _regUid = data.Uid ?? string.Empty;
                                _regSecret = data.Secret;
                                _secretKey = _regSecret;       // auto-fill the legacy input
                                _showSecret = true;            // reveal panel in UI
                            }
                            catch (Exception ex)
                            {
                                _regError = ex.Message;
                            }
                            finally
                            {
                                _creatingSecret = false;
                            }
                        });
                    }
                    ImGui.SameLine();
                }
                else
                {
                    UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.BDC7E887", "Creating account…"), ImGuiColors.DalamudYellow);
                }
            }

            // Error surface
            if (!string.IsNullOrEmpty(_regError))
            {
                UiSharedService.ColorTextWrapped(_regError!, ImGuiColors.DalamudRed);
            }

            // Show the secret panel once created
            if (_showSecret && !string.IsNullOrEmpty(_regSecret))
            {
                UiSharedService.DistanceSeparator();
                UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.522c36f2", "Your one-time secret key (copy & store safely):"));
                ImGui.InputText("##reg-secret", ref _regSecret, 64, ImGuiInputTextFlags.ReadOnly);
                ImGui.SameLine();
                if (ImGui.Button(_uiShared.L("UI.IntroUI.af74f7c5", "Copy"))) ImGui.SetClipboardText(_regSecret);

                if (!string.IsNullOrEmpty(_regUid))
                    UiSharedService.TextWrapped(string.Format(_uiShared.L("UI.IntroUI.ad3a4f84", "UID: {0}"), _regUid));

                UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.f5ca7f29", "This box is here ONLY to make it easy to copy your key and save it somewhere. Please make sure you click Save below."), ImGuiColors.ParsedGreen);
            }

            if (_useLegacyLogin)
            {
                var text = "Enter Secret Key";
                var buttonText = "Save";
                var buttonWidth = _secretKey.Length != 64 ? 0 : ImGuiHelpers.GetButtonSize(buttonText).X + ImGui.GetStyle().ItemSpacing.X;
                var textSize = ImGui.CalcTextSize(text);

                ImGui.AlignTextToFramePadding();
                ImGui.TextUnformatted(text);
                ImGui.SameLine();
                ImGui.SetNextItemWidth(UiSharedService.GetWindowContentRegionWidth() - ImGui.GetWindowContentRegionMin().X - buttonWidth - textSize.X);
                ImGui.InputText("", ref _secretKey, 64);
                if (_secretKey.Length > 0 && _secretKey.Length != 64)
                {
                    UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.54fd9f64", "Your secret key must be exactly 64 characters long. Don't enter your Lodestone auth here."), ImGuiColors.DalamudRed);
                }
                else if (_secretKey.Length == 64 && !HexRegex().IsMatch(_secretKey))
                {
                    UiSharedService.ColorTextWrapped(_uiShared.L("UI.IntroUI.463b0dba", "Your secret key can only contain ABCDEF and the numbers 0-9."), ImGuiColors.DalamudRed);
                }
                else if (_secretKey.Length == 64)
                {
                    //ImGui.SameLine();
                    //if (ImGui.Button(buttonText))
                    //{
                    //    if (_serverConfigurationManager.CurrentServer == null) _serverConfigurationManager.SelectServer(0);

                    //    // make absolutely sure we are in legacy-secret mode before mapping the character
                    //    selectedServer = _serverConfigurationManager.GetServerByIndex(0);
                    //    if (selectedServer != null && selectedServer.UseOAuth2)
                    //    {
                    //        selectedServer.UseOAuth2 = false;
                    //        _serverConfigurationManager.Save();
                    //    }


                    //    if (!_serverConfigurationManager.CurrentServer!.SecretKeys.Any())
                    //    {
                    //        _serverConfigurationManager.CurrentServer!.SecretKeys.Add(_serverConfigurationManager.CurrentServer.SecretKeys.Select(k => k.Key).LastOrDefault() + 1, new SecretKey()
                    //        {
                    //            FriendlyName = $"Secret Key added on Setup ({DateTime.Now:yyyy-MM-dd})",
                    //            Key = _secretKey,
                    //        });
                    //        _serverConfigurationManager.AddCurrentCharacterToServer();
                    //    }
                    //    else
                    //    {
                    //        _serverConfigurationManager.CurrentServer!.SecretKeys[0] = new SecretKey()
                    //        {
                    //            FriendlyName = $"Secret Key added on Setup ({DateTime.Now:yyyy-MM-dd})",
                    //            Key = _secretKey,
                    //        };
                    //    }
                    //    _secretKey = string.Empty;
                    //    _ = Task.Run(() => _uiShared.ApiController.CreateConnectionsAsync());
                    //}

                    ImGui.SameLine();
                    if (ImGui.Button(buttonText))
                    {
                        if (_serverConfigurationManager.CurrentServer == null)
                            _serverConfigurationManager.SelectServer(0);

                        // make absolutely sure we are in legacy-secret mode before mapping the character
                        selectedServer = _serverConfigurationManager.GetServerByIndex(0);
                        if (selectedServer != null && selectedServer.UseOAuth2)
                        {
                            selectedServer.UseOAuth2 = false;
                            _serverConfigurationManager.Save();
                        }

                        if (!_serverConfigurationManager.CurrentServer!.SecretKeys.Any())
                        {
                            _serverConfigurationManager.CurrentServer.SecretKeys.Add(
                                _serverConfigurationManager.CurrentServer.SecretKeys.Select(k => k.Key).LastOrDefault() + 1,
                                new SecretKey
                                {
                                    FriendlyName = $"Secret Key added on Setup ({DateTime.Now:yyyy-MM-dd})",
                                    Key = _secretKey,
                                });

                            // map character now that we're definitely in legacy mode
                            _serverConfigurationManager.AddCurrentCharacterToServer();
                            _serverConfigurationManager.Save();
                        }
                        else
                        {
                            _serverConfigurationManager.CurrentServer.SecretKeys[0] = new SecretKey
                            {
                                FriendlyName = $"Secret Key added on Setup ({DateTime.Now:yyyy-MM-dd})",
                                Key = _secretKey,
                            };

                            // ensure mapping exists/updated even when replacing slot 0
                            _serverConfigurationManager.AddCurrentCharacterToServer();
                            _serverConfigurationManager.Save();
                        }

                        _secretKey = string.Empty;

                        // reconnect so the session immediately picks up the secret
                        _ = Task.Run(() => _uiShared.ApiController.CreateConnectionsAsync());
                    }

                }
            }
            else
            {
                if (string.IsNullOrEmpty(selectedServer.OAuthToken))
                {
                    UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.cc73b96f", "Press the button below to verify the server has OAuth2 capabilities. Afterwards, authenticate using Discord in the Browser window."));
                    _uiShared.DrawOAuth(selectedServer);
                }
                else
                {
                    UiSharedService.ColorTextWrapped(string.Format(_uiShared.L("UI.IntroUI.2dc98235", "OAuth2 is connected. Linked to: Discord User {0}"), _serverConfigurationManager.GetDiscordUserFromToken(selectedServer)), ImGuiColors.HealerGreen);
                    UiSharedService.TextWrapped(_uiShared.L("UI.IntroUI.680633e4", "Now press the update UIDs button to get a list of all of your UIDs on the server."));
                    _uiShared.DrawUpdateOAuthUIDsButton(selectedServer);
                    var playerName = _dalamudUtilService.GetPlayerName();
                    var playerWorld = _dalamudUtilService.GetHomeWorldId();
                    UiSharedService.TextWrapped(string.Format(_uiShared.L("UI.IntroUI.27ad229b", "Once pressed, select the UID you want to use for your current character {0}. If no UIDs are visible, make sure you are connected to the correct Discord account. If that is not the case, use the unlink button below (hold CTRL to unlink)."), _dalamudUtilService.GetPlayerName()));
                    _uiShared.DrawUnlinkOAuthButton(selectedServer);

                    var auth = selectedServer.Authentications.Find(a => string.Equals(a.CharacterName, playerName, StringComparison.Ordinal) && a.WorldId == playerWorld);
                    if (auth == null)
                    {
                        auth = new Authentication()
                        {
                            CharacterName = playerName,
                            WorldId = playerWorld
                        };
                        selectedServer.Authentications.Add(auth);
                        _serverConfigurationManager.Save();
                    }

                    _uiShared.DrawUIDComboForAuthentication(0, auth, selectedServer.ServerUri);

                    using (ImRaii.Disabled(string.IsNullOrEmpty(auth.UID)))
                    {
                        if (_uiShared.IconTextButton(Dalamud.Interface.FontAwesomeIcon.Link, _uiShared.L("UI.IntroUI.9249af5e", "Connect to Service")))
                        {
                            _ = Task.Run(() => _uiShared.ApiController.CreateConnectionsAsync());
                        }
                    }
                    if (string.IsNullOrEmpty(auth.UID))
                        UiSharedService.AttachToolTip(_uiShared.L("UI.IntroUI.112b5c75", "Select a UID to be able to connect to the service"));
                }
            }
        }
        else
        {
            Mediator.Publish(new SwitchToMainUiMessage());
            IsOpen = false;
        }
    }
    private void GetToSLocalization(int changeLanguageTo = -1)
    {
        if (changeLanguageTo != -1)
        {
            _uiShared.LoadLocalization(_languages.ElementAt(changeLanguageTo).Value);
        }

        _tosParagraphs = [Strings.ToS.Paragraph1, Strings.ToS.Paragraph2, Strings.ToS.Paragraph3, Strings.ToS.Paragraph4, Strings.ToS.Paragraph5, Strings.ToS.Paragraph6];
    }

    [GeneratedRegex("^([A-F0-9]{2})+")]
    private static partial Regex HexRegex();
}