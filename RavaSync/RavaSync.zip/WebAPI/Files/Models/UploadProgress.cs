﻿namespace RavaSync.WebAPI.Files.Models;

public record UploadProgress(long Uploaded, long Size);