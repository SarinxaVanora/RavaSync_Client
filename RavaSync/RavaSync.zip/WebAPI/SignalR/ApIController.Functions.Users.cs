﻿using RavaSync.API.Data;
using RavaSync.API.Dto;
using RavaSync.API.Dto.Group;
using RavaSync.API.Dto.User;
using RavaSync.Services.Mediator;
using CharacterDataPushSanitizer = RavaSync.PlayerData.Data.CharacterDataPushSanitizer;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Logging;
using System.Text;

namespace RavaSync.WebAPI;

#pragma warning disable MA0040
public partial class ApiController
{
    public async Task<bool> PushCharacterData(CharacterData data, List<UserData> visibleCharacters)
    {
        if (!IsConnected) return false;

        try
        {
            return await PushCharacterDataInternal(data, [.. visibleCharacters]).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            Logger.LogDebug("Upload operation was cancelled");
            return false;
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Error during upload of files");
            return false;
        }
    }

    public async Task<string?> UserSetAlias(string desiredAlias)
    {
        if (!IsConnected) return "Not connected to server.";
        return await _mareHub!.InvokeAsync<string?>(nameof(UserSetAlias), desiredAlias).ConfigureAwait(false);
    }

    public async Task<string?> GroupSetAlias(GroupDto group, string desiredAlias)
    {
        if (!IsConnected) return "Not connected to server.";
        return await _mareHub!.InvokeAsync<string?>(nameof(GroupSetAlias), group, desiredAlias).ConfigureAwait(false);
    }

    public async Task UserAddPair(UserDto user)
    {
        if (!IsConnected) return;
        await _mareHub!.SendAsync(nameof(UserAddPair), user).ConfigureAwait(false);
    }

    public async Task UserDelete()
    {
        CheckConnection();
        await _mareHub!.SendAsync(nameof(UserDelete)).ConfigureAwait(false);
        await CreateConnectionsAsync().ConfigureAwait(false);
    }

    public async Task<List<OnlineUserIdentDto>> UserGetOnlinePairs(CensusDataDto? censusDataDto)
    {
        return await _mareHub!.InvokeAsync<List<OnlineUserIdentDto>>(nameof(UserGetOnlinePairs), censusDataDto).ConfigureAwait(false);
    }

    public async Task<List<UserFullPairDto>> UserGetPairedClients()
    {
        return await _mareHub!.InvokeAsync<List<UserFullPairDto>>(nameof(UserGetPairedClients)).ConfigureAwait(false);
    }

    public async Task<UserProfileDto> UserGetProfile(UserDto dto)
    {
        if (!IsConnected) return new UserProfileDto(dto.User, Disabled: false, IsNSFW: null, ProfilePictureBase64: null, Description: null);
        return await _mareHub!.InvokeAsync<UserProfileDto>(nameof(UserGetProfile), dto).ConfigureAwait(false);
    }

    public async Task UserPushData(UserCharaDataMessageDto dto)
    {
        if (!TryPrepareUserPushData(dto, "direct")) return;

        try
        {
            await _mareHub!.InvokeAsync(nameof(UserPushData), dto).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to Push character data");
        }
    }

    private async Task<bool> TryUserPushData(UserCharaDataMessageDto dto)
    {
        if (!TryPrepareUserPushData(dto, "final")) return false;

        try
        {
            await _mareHub!.InvokeAsync(nameof(UserPushData), dto).ConfigureAwait(false);
            return true;
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to Push character data");
            return false;
        }
    }

    private bool TryPrepareUserPushData(UserCharaDataMessageDto? dto, string stage)
    {
        if (dto?.CharaData == null)
        {
            Logger.LogWarning("Skipped UserPushData ({stage}) because character data was null", stage);
            return false;
        }

        var sanitizerResult = CharacterDataPushSanitizer.SanitizeForPush(dto.CharaData);
        if (sanitizerResult.Changed)
        {
            Logger.LogDebug("Removed server-invalid outbound data before UserPushData ({stage}): {replacements} replacement(s), {gamePaths} game path(s), {buckets} object bucket(s), {honorific} honorific payload(s)",
                stage,
                sanitizerResult.RemovedReplacements,
                sanitizerResult.RemovedGamePaths,
                sanitizerResult.RemovedBuckets,
                sanitizerResult.RemovedHonorificData);
        }

        return true;
    }

    public async Task SetBulkPermissions(BulkPermissionsDto dto)
    {
        CheckConnection();

        try
        {
            await _mareHub!.InvokeAsync(nameof(SetBulkPermissions), dto).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to set permissions");
        }
    }

    public async Task UserRemovePair(UserDto userDto)
    {
        if (!IsConnected) return;
        await _mareHub!.SendAsync(nameof(UserRemovePair), userDto).ConfigureAwait(false);
    }

    public async Task UserSetPairPermissions(UserPermissionsDto userPermissions)
    {
        await SetBulkPermissions(new(new(StringComparer.Ordinal)
        {
                { userPermissions.User.UID, userPermissions.Permissions }
            }, new(StringComparer.Ordinal))).ConfigureAwait(false);
    }

    public async Task UserSetProfile(UserProfileDto userDescription)
    {
        if (!IsConnected) return;
        await _mareHub!.InvokeAsync(nameof(UserSetProfile), userDescription).ConfigureAwait(false);
    }

    public async Task UserUpdateDefaultPermissions(DefaultPermissionsDto defaultPermissionsDto)
    {
        CheckConnection();
        await _mareHub!.InvokeAsync(nameof(UserUpdateDefaultPermissions), defaultPermissionsDto).ConfigureAwait(false);
    }

    private async Task<bool> PushCharacterDataInternal(CharacterData character, List<UserData> visibleCharacters)
    {
        var sanitizerResult = CharacterDataPushSanitizer.SanitizeForPush(character);
        if (sanitizerResult.Changed)
        {
            Logger.LogDebug("Removed server-invalid outbound data before UserPushData: {replacements} replacement(s), {gamePaths} game path(s), {buckets} object bucket(s), {honorific} honorific payload(s)",
                sanitizerResult.RemovedReplacements,
                sanitizerResult.RemovedGamePaths,
                sanitizerResult.RemovedBuckets,
                sanitizerResult.RemovedHonorificData);
        }

        Logger.LogInformation("Pushing character data for {hash} to {charas}", character.DataHash.Value, string.Join(", ", visibleCharacters.Select(c => c.AliasOrUID)));
        StringBuilder sb = new();
        foreach (var kvp in character.FileReplacements.ToList())
        {
            sb.AppendLine($"FileReplacements for {kvp.Key}: {kvp.Value.Count}");
        }
        foreach (var item in character.GlamourerData)
        {
            sb.AppendLine($"GlamourerData for {item.Key}: {!string.IsNullOrEmpty(item.Value)}");
        }
        Logger.LogDebug("Chara data contained: {nl} {data}", Environment.NewLine, sb.ToString());

        CensusDataDto? censusDto = null;
        if (_serverManager.SendCensusData && _lastCensus != null)
        {
            var world = await _dalamudUtil.GetWorldIdAsync().ConfigureAwait(false);
            censusDto = new((ushort)world, _lastCensus.RaceId, _lastCensus.TribeId, _lastCensus.Gender);
            Logger.LogDebug("Attaching Census Data: {data}", censusDto);
        }

        return await TryUserPushData(new(visibleCharacters, character, censusDto)).ConfigureAwait(false);
    }

}
#pragma warning restore MA0040