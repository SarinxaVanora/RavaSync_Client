﻿using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using RavaSync.API.Dto.Group;
using RavaSync.PlayerData.Pairs;
using RavaSync.Services.Mediator;
using RavaSync.WebAPI;
using System.Numerics;

namespace RavaSync.UI.Components.Popup;

public class BanUserPopupHandler : IPopupHandler
{
    private readonly ApiController _apiController;
    private readonly UiSharedService _uiSharedService;
    private string _banReason = string.Empty;
    private GroupFullInfoDto _group = null!;
    private Pair _reportedPair = null!;

    public BanUserPopupHandler(ApiController apiController, UiSharedService uiSharedService)
    {
        _apiController = apiController;
        _uiSharedService = uiSharedService;
    }

    public Vector2 PopupSize => new(500, 250);

    public bool ShowClose => true;

    public void DrawContent()
    {
        UiSharedService.TextWrapped(_uiSharedService.L("UI.BanUserPopupHandler.5d28cd21", "User ") + (_reportedPair.UserData.AliasOrUID) + _uiSharedService.L("UI.BanUserPopupHandler.5818d7bd", " will be banned and removed from this Syncshell."));
        ImGui.InputTextWithHint("##banreason", _uiSharedService.L("UI.BanUserPopupHandler.8178f0ff", "Ban Reason"), ref _banReason, 255);

        if (_uiSharedService.IconTextButton(FontAwesomeIcon.UserSlash, _uiSharedService.L("UI.BanUserPopupHandler.82bb897f", "Ban User")))
        {
            ImGui.CloseCurrentPopup();
            var reason = _banReason;
            _ = _apiController.GroupBanUser(new GroupPairDto(_group.Group, _reportedPair.UserData), reason);
            _banReason = string.Empty;
        }
        UiSharedService.TextWrapped(_uiSharedService.L("UI.BanUserPopupHandler.3833f407", "The reason will be displayed in the banlist. The current server-side alias if present (Vanity ID) will automatically be attached to the reason."));
    }

    public void Open(OpenBanUserPopupMessage message)
    {
        _reportedPair = message.PairToBan;
        _group = message.GroupFullInfoDto;
        _banReason = string.Empty;
    }
}